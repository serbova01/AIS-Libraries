package com.example.pw3

import android.R.id.edit
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.text.InputFilter
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.pw3.models.User
import com.example.pw3.registration.RegistrationActivity
import java.io.IOException
import java.sql.SQLException


class LoginActivity : AppCompatActivity() {

    private lateinit var et_login_login:EditText
    private lateinit var et_login_pass:EditText

    private lateinit var mSettings: SharedPreferences
    private lateinit var mDBHelper: Server
    private var user: User? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
        }

        this.title = getString(R.string.authorize)

        init()
    }

    fun init(){
        initComponents()
        mSettings = getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        var editor = mSettings.edit()
        editor.putString("email", "").apply()
        editor.putBoolean("is_logged", false).apply()
        mDBHelper = Server(this)
        mDBHelper.connect()
    }

    private fun initComponents() {
        et_login_login = findViewById(R.id.et_login_login)
        et_login_pass = findViewById(R.id.et_login_pass)

        val filterLogin =
            InputFilter { source, start, end, dest, dstart, dend ->
                for (i in start until end) {
                    if (!Character.isLetterOrDigit(source[i])) {
                        return@InputFilter ""
                    }
                }
                null
            }
        et_login_login.setFilters(arrayOf(filterLogin))

        val filterPass =
            InputFilter { source, start, end, dest, dstart, dend ->
                for (i in start until end) {
                    if (Character.isWhitespace(source[i])) {
                        return@InputFilter ""
                    }
                }
                null
            }
        et_login_pass.setFilters(arrayOf(filterPass))
    }

    fun onSignIn(view: View) {
        if (checkNull()){
            var login = et_login_login.text.toString()
            var pass = et_login_pass.text.toString()
            user = mDBHelper.checkAuthorizeUser(login, pass)
            if (user == null){
                Toast.makeText(this, getString(R.string.noFindUser), Toast.LENGTH_SHORT).show()
            }else{
                var editor = mSettings.edit()
                editor.putString("email", user!!.email).apply()
                editor.putBoolean("is_logged", true).apply()
                val intent = Intent(this@LoginActivity, MainActivity::class.java)
                startActivity(intent)
            }
        }
    }

    fun checkNull():Boolean{
        if (et_login_login.text.trim().isEmpty()){
            Toast.makeText(this, getString(R.string.loginNull), Toast.LENGTH_SHORT).show()
            return false
        }
        if (et_login_pass.text.trim().isEmpty()){
            Toast.makeText(this, getString(R.string.passNull), Toast.LENGTH_SHORT).show()
            return false
        }

        return true
    }

    fun onReg(view: View) {
        mSettings.edit().putString("email", "")
        mSettings.edit().putBoolean("is_logged", false)
        val intent = Intent(this@LoginActivity, RegistrationActivity::class.java)
        startActivity(intent)
    }
}