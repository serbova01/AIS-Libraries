package com.example.pw3.registration

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.telephony.SmsManager
import android.text.InputFilter
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.pw3.MainActivity
import com.example.pw3.R
import com.example.pw3.Server
import com.example.pw3.models.Subscriber
import com.example.pw3.models.User
import com.google.android.material.textfield.TextInputLayout


class PhNumVerificationActivity : AppCompatActivity() {

    lateinit var tv_confimPhNum:TextView
    lateinit var et_codeConfim:EditText
    lateinit var et_phoneNumber:EditText
    lateinit var btn_checkCode:AppCompatButton
    lateinit var btn_sendCode:AppCompatButton
    lateinit var til_phonenumber:TextInputLayout
    lateinit var tv_errorPhNum:TextView

    lateinit var user: User
    private var code = ""
    val permissionRequest = 101
    var phoneNumber:String = ""
    lateinit var mSettings: SharedPreferences
    private lateinit var mDBHelper: Server

    var maskPhNum = "+0 (000) 000-00-00"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ph_num_verification)

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
        }

        mSettings = getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences

        val bundle = intent.extras
        if (bundle != null){
            user = User(bundle.getString("login"), bundle.getString("password"), bundle.getString("email"),
                bundle.getString("role"))
            this.title = getString(R.string.verificationPhNumber)
        }

        //user = intent.extras?.get("newUser") as User
        init()
        //requestSmsSendPermission()
    }

    fun init(){
        //connect()
        mDBHelper = Server(this)
        mDBHelper.connect()

        tv_confimPhNum = findViewById(R.id.tv_confimPhNum)
        et_codeConfim = findViewById(R.id.et_codeConfim)
        et_phoneNumber = findViewById(R.id.et_phoneNumber)
        //et_phoneNumber.setOnEditorActionListener(ActionListener.newInstance(this));
        btn_checkCode = findViewById(R.id.btn_checkCode)
        //btn_checkCode.isEnabled = false
        btn_checkCode.setOnClickListener {
            checkCode()
        }
        btn_sendCode = findViewById(R.id.btn_sendCode)
        btn_sendCode.setOnClickListener {
            sendCode()
        }
        tv_errorPhNum = findViewById(R.id.tv_errorPhNum)

        val filterName = InputFilter { source, start, end, dest, dstart, dend ->
            for (i in start until end) {
                var j = et_phoneNumber.text.toString().length
                var s = source[i]
                var s1 = maskPhNum[j]

                if (!((Character.isDigit(source[i]) &&
                            Character.isDigit(maskPhNum[j])) ||
                            source[i].toString().equals(maskPhNum[j].toString()) ||
                            (j == 1 && source[i].equals("7")))) {
                    tv_errorPhNum.visibility = TextView.VISIBLE
                    return@InputFilter ""
                }
            }
            null
        }
        et_phoneNumber.filters = arrayOf(filterName)
    }

    private fun sendMessage() {

        val permissionCheck = ContextCompat.checkSelfPermission(this,
            android.Manifest.permission.SEND_SMS)
        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
            myMessage()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(
                android.Manifest.permission.SEND_SMS), permissionRequest)
        }
    }
    private fun myMessage() {
        val myNumber: String = et_phoneNumber.text.toString().trim()
        if (myNumber == "") {
            Toast.makeText(this, "Field cannot be empty", Toast.LENGTH_SHORT).show()
        } else {
            /*if (correctPhNumber(myNumber)) {

            } else {
                Toast.makeText(this, getString(R.string.phNumInCorrect), Toast.LENGTH_SHORT).show()
            }*/
            val smsManager: SmsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(myNumber, null, code, null, null)
            Toast.makeText(this, getString(R.string.codeSend), Toast.LENGTH_SHORT).show()
        }
    }

    private fun correctPhNumber(myNumber: String): Boolean {
        return true
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults:
    IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                myMessage();
            } else {
                Toast.makeText(this, "You don't have required permission to send a message",
                    Toast.LENGTH_SHORT).show();
            }
        }
    }

    private fun sendCode() {
        generateCode()
        code = "111"
        sendMessage()
        phoneNumber = et_phoneNumber.text.toString()

        btn_checkCode.isEnabled = true

    }


    private fun checkCode() {
        if (checkNull()) {
            if (et_codeConfim.text.toString().equals(code)) {
                var subscriber = mDBHelper.findSubscriberByPhNumber(phoneNumber)
                user.subscriber = subscriber
                if (subscriber != null && subscriber.emailS == null){
                    //если этот номер зарегистрирован в системе, но абонент не зарегистрирован в приложении
                    var numInsertRow: Long = mDBHelper.insertUser(user)
                    if (numInsertRow>0){
                        goToMainActivity()
                    }else Toast.makeText(this, "Не удалось добавить зарегистрированного абонента", Toast.LENGTH_SHORT).show()
                }else{
                    if (subscriber == null){
                        val intent =
                            Intent(this@PhNumVerificationActivity, FindLibraryActivity::class.java)

                        //intent.putExtra("newUser", user)
                        val newUser = Bundle()
                        newUser.putString("login", user.login)
                        newUser.putString("email", user.email)
                        newUser.putString("password", user.password)
                        newUser.putString("role", user.role)
                        newUser.putString("phNumber", phoneNumber)
                        intent.putExtras(newUser)
                        startActivity(intent)
                    }else{
                        if (subscriber.emailS != user.email){
                            createAlert(subscriber)
                        }
                    }
                }

            } else {
                Toast.makeText(this, getString(R.string.falseCode), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun createAlert(subscriber: Subscriber) {
        val alertDialog = AlertDialog.Builder(this@PhNumVerificationActivity)
        alertDialog.setTitle(R.string.alertTitle_phNumIsSystemWithOtherEmail)
        var text = "Такой номер телефона зарегистрирован в системе с другим email-ом: " + subscriber.emailS +
                " .\n Хотите восстановить профиль или изменить данные профиля?"

        alertDialog.setMessage(text)
        alertDialog.setIcon(R.mipmap.ic_launcher)
        alertDialog.setPositiveButton("Восстановить профиль"){dialog, id->
            restoreProfile(subscriber)
        }
        alertDialog.setNegativeButton("Изменить данные"){dialog, id->
            var numInsertRow: Long = mDBHelper.insertUser(user)
            if(numInsertRow <=0) Toast.makeText(this, "Не удалось добавить зарегистрированного абонента", Toast.LENGTH_SHORT).show()
            else{
                goToMainActivity()
            }
        }

        alertDialog.show()
    }

    private fun goToMainActivity() {
        mSettings = getSharedPreferences("my_storage", Context.MODE_PRIVATE)
        val editor = mSettings.edit()
        editor.putBoolean("is_logged", true).apply()
        editor.putString("email", user.email).apply()
        val intent = Intent(this@PhNumVerificationActivity, MainActivity::class.java)
        startActivity(intent)
    }


    private fun restoreProfile(subscriber: Subscriber) {
        user = mDBHelper.findUserByEmail(user.subscriber?.emailS ?: "")
        goToMainActivity()
    }

    private fun checkNull(): Boolean {
        if (et_codeConfim.text.isNotEmpty() and et_phoneNumber.text.isNotEmpty()){
            return true
        }else{
            if (et_codeConfim.text.isEmpty())
                Toast.makeText(this, getString(R.string.confimCodeNull), Toast.LENGTH_SHORT).show()
            else{
                if (et_phoneNumber.text.isEmpty())
                    Toast.makeText(this, getString(R.string.phoneNumberNull), Toast.LENGTH_SHORT).show()
            }
        }

        return false
    }

    private fun generateCode() {
        val num = IntRange(0, 9)
        var i:Int = 1
        code = ""
        while (i<5){
            code += num.random().toString()
            i++
        }
    }

    fun shouldShowError(): Boolean {
        var number = et_phoneNumber.text.toString()
        val textLength: Int = et_phoneNumber.text.toString().length
        if (textLength - 1 >= 0){
            return !number[textLength-1].equals(maskPhNum[textLength-1])
        }
        return true
    }
//"+0 (000) 000-00-00"
    fun showError() {
        til_phonenumber.error = getString(R.string.error)
    }

    fun hideError() {
        til_phonenumber.error = " "
    }


}