package com.example.pw3.Adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.R
import com.example.pw3.models.Catalog


class ItemCatalogAdapter(public var catalog:ArrayList<Catalog>) :
    RecyclerView.Adapter<ItemCatalogAdapter.ItemCatalogViewHolder>(){

    var onItemClick: ((Catalog) -> Unit)? = null
    lateinit var view:View

    inner class ItemCatalogViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){
        val imageView : ImageView = itemView.findViewById(R.id.iv_imageEdition)
        val textView_title : TextView = itemView.findViewById(R.id.tv_nameItem)
        val textView_text : TextView = itemView.findViewById(R.id.tv_discriptionItem)
        init {
            itemView.setOnClickListener {
                onItemClick?.invoke(catalog[adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemCatalogViewHolder {
        view = LayoutInflater.from(parent.context).inflate(R.layout.item_catalog_layout, parent, false)
        return ItemCatalogViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemCatalogViewHolder, position: Int) {
        val itemCatalog = catalog[position]
        itemCatalog.image?.let { holder.imageView.setImageResource(it) }
        holder.textView_title.text = itemCatalog.nameBook
        holder.textView_text.text = itemCatalog.getShortText()
    }

    override fun getItemCount(): Int {
        return catalog.size
    }

    fun filterList(filterlist: ArrayList<Catalog>) {
        catalog = filterlist
        notifyDataSetChanged()
    }

}