package com.example.pw3.models

import java.io.Serializable

class Library(): Serializable{
    var id =0
    var nameL = ""
    var cityPhNum = ""
    var email = ""
    var districtL = ""
    var cityL = ""
    var streetL = ""
    var houseL = ""
    var address = ""
    constructor(id:Int, nameL:String, cityPhNum:String, email:String, address:String) : this(){
        this.id =id
        this.nameL = nameL
        this.cityPhNum = cityPhNum
        this.email = email
        this.address = address

        var arrAddress = address.split(",")
        this.districtL = arrAddress[0]
        this.cityL = arrAddress[1]
        this.streetL = arrAddress[2]
        this.houseL = arrAddress[3]
    }

    override fun toString():String{
        return "$nameL : $cityL, $streetL, $houseL";
    }
}