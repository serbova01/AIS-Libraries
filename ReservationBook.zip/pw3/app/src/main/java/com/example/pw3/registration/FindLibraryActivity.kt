package com.example.pw3.registration

import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.widget.AppCompatButton
import com.example.pw3.R
import com.example.pw3.Server
import com.example.pw3.models.Library
import com.example.pw3.models.User

class FindLibraryActivity : AppCompatActivity() {

    lateinit var spinner:Spinner
    lateinit var btn_next: AppCompatButton

    var selectedLib:Library = Library()
    var user: User = User()
    var phNumber = ""
    lateinit var list_libraries:ArrayList<Library>
    private lateinit var mDBHelper: Server
    lateinit var mSettings: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_find_library)

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
        }

        this.title = getString(R.string.title_findLibActivity)
        //user = intent.extras?.get("user") as User
        val bundle = intent.extras
        if (bundle != null){
            user = User(bundle.getString("login"), bundle.getString("password"), bundle.getString("email"),
                bundle.getString("role"))
            phNumber = bundle.getString("phNumber").toString()
        }

        init()
    }

    fun init(){
        spinner = findViewById<Spinner>(R.id.s_libraries)
        mDBHelper = Server(this)
        mDBHelper.connect()
        initSpinner()


        btn_next = findViewById<AppCompatButton>(R.id.tv_next)
        btn_next.setOnClickListener{
            if (selectedLib.id > 0){
                val intent = Intent(this@FindLibraryActivity, RegSubscriberActivity::class.java)
                //intent.putExtra("selectedLib", selectedLib)
                //intent.putExtra("user", user)
                //intent.putExtra("phNumber", phNumber)
                val data = Bundle()
                data.putString("user.login", user.login)
                data.putString("user.email", user.email)
                data.putString("user.password", user.password)
                data.putString("user.role", user.role)
                data.putString("phNumber", phNumber)
                data.putInt("selectedLib.id", selectedLib.id)
                intent.putExtras(data);
                startActivity(intent)
            }else{
                Toast.makeText(this, getString(R.string.selectedLibNull), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun initSpinner() {
        //list_libraries = listOf(
            //Library(1, "Библиотека 1", "0-00-00", "library1@gmail.ru", "Владимирская", "Муром", "Владимирская", "12")
        //)
        var list_strLib = arrayListOf<String>()
        list_libraries = mDBHelper.listLibraries()
        list_libraries.forEach{list_strLib.add(it.toString())}
        // Создаем адаптер ArrayAdapter с помощью массива строк и стандартной разметки элемета spinner
        val adapter: ArrayAdapter<String> =
            ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, list_strLib.toTypedArray())
        // Определяем разметку для использования при выборе элемента
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        // Применяем адаптер к элементу spinner
        spinner.adapter = adapter
        spinner.onItemSelectedListener=
            object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(parent: AdapterView<*>,
                                            view: View,
                                            position: Int,
                                            id: Long
                ) {
                    // Получаем выбранный объект
                    val item = parent.getItemAtPosition(position) as String
                    selectedLib = list_libraries[position]
                    btn_next.setTextColor(Color.parseColor("#FF0000"))
                }

                override fun onNothingSelected(parent: AdapterView<*>?) {}
            }
    }
}