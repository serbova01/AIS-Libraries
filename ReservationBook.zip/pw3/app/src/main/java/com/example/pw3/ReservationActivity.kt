package com.example.pw3

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Typeface
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.*
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.Adapters.ItemBasketAdapter
import com.example.pw3.Adapters.ItemReservWithLibAdapter
import com.example.pw3.Adapters.ItemReservationAdapter
import com.example.pw3.models.Basket
import com.example.pw3.models.Library
import com.example.pw3.models.ReservationPrewie
import com.example.pw3.models.User

class ReservationActivity : AppCompatActivity() {

    lateinit var rv_reservation:RecyclerView
    lateinit var btn_reservation:AppCompatButton

    lateinit var listReservPrewie:ArrayList<ReservationPrewie>
    lateinit var mSettings: SharedPreferences
    private lateinit var mDBHelper: Server
    lateinit var user: User

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reservation)

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
        }
        this.title = getString(R.string.reservation)

        rv_reservation = findViewById(R.id.rv_reservation)
        btn_reservation = findViewById(R.id.btn_reservation)
        btn_reservation.setOnClickListener(){
            reservation()
        }

        init()

    }

    private fun reservation() {
        var error = false
        for (item1 in listReservPrewie){
            for(item2 in item1.list){
                if (mDBHelper.checkNumEditionInLib(item2)){
                    error = false
                }else{
                    Toast.makeText(this,
                        getString(R.string.numEditionInLibNull) + "\n" + item2.catalog.nameBook +
                    "\t" + item2.catalog.publHouse, Toast.LENGTH_LONG).show()
                    error = true
                    break
                }
            }
            if (error)
                break
        }
        if (!error){
            var num:Long = mDBHelper.insertReservation(listReservPrewie, user)
        }
    }

    fun init(){
        mDBHelper = Server(this)
        mDBHelper.connect()
        mSettings = this.getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        var is_logged = mSettings!!.getBoolean("is_logged", false)
        var email = ""
        if (is_logged){
            email = mSettings!!.getString("email", "").toString()
            user = mDBHelper.findUserByEmail(email)
            var arr:ArrayList<Int>?
            var list = ArrayList<Basket>()

            val bundle = intent.extras
            if (bundle != null){
                arr = bundle.getIntegerArrayList("list")
                if (arr != null) {
                    arr.forEach{ (list as ArrayList<Basket>).add(mDBHelper.findBasketById(it)) }
                }
            }

            listReservPrewie = ArrayList<ReservationPrewie>()
            for(b in list){
                if (listReservPrewie.any{it.library.id == b.library.id})
                    listReservPrewie.first{it.library.id == b.library.id}.list.add(b)
                else
                    (listReservPrewie as ArrayList<ReservationPrewie>).add(ReservationPrewie(b.library, arrayListOf<Basket>(b)))
            }
            rv_reservation.setHasFixedSize(true)
            rv_reservation.layoutManager = LinearLayoutManager(this)
            var itemReservWithLibAdapter:ItemReservWithLibAdapter =
                ItemReservWithLibAdapter(this, listReservPrewie as ArrayList<ReservationPrewie>)
            rv_reservation.adapter=itemReservWithLibAdapter
        }


    }
}