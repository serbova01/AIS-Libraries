package com.example.pw3.models

class NumInLib(num:Int, reg:Boolean) {
    var num = num
    var library = Library()
    var reg = reg
    constructor(num:Int, library:Library, reg:Boolean): this(num, reg){
        this.library = library
    }
}