package com.example.pw3

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.Adapters.LibWithEdAdapter
import com.example.pw3.models.*

class EditionActivity : AppCompatActivity() {

    lateinit var iv_image:ImageView
    lateinit var tv_edition_nameBook:TextView
    lateinit var tv_edition_authors:TextView
    lateinit var tv_edition_discription:TextView
    lateinit var tv_edition_publHouse:TextView
    lateinit var tv_edition_yearPubl:TextView
    lateinit var tv_edition_numPages:TextView
    lateinit var tv_edition_ISBN:TextView
    lateinit var tv_edition_cycle:TextView
    lateinit var rv_edition_libs:RecyclerView
    lateinit var btn_edition_reservation:AppCompatButton
    lateinit var btn_edition_openRequest:AppCompatButton
    lateinit var btn_edition_favorite:ImageButton

    private lateinit var mDBHelper: Server
    lateinit var mSettings: SharedPreferences
    var user: User? = null
    lateinit var edition:Catalog
    var select: NumInLib? = null
    private var id:Int = 0
    private lateinit var itemLibWithEdAdapter: LibWithEdAdapter
    var basket:Basket? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edition)

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
        }
        this.title = getString(R.string.edition)

        initComponents()

        id = intent.getIntExtra("id", 0)
        init()
    }

    fun init(){
        mDBHelper = Server(this)
        mDBHelper.connect()
        mSettings = this.getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        var is_logged = mSettings!!.getBoolean("is_logged", false)
        var email = ""
        edition = mDBHelper.findEditionById(id)

        if (edition != null){
            tv_edition_nameBook.text = edition.nameBook
            tv_edition_authors.text = edition.getShortText()
            tv_edition_discription.text = edition.discription
            tv_edition_publHouse.text= edition.publHouse
            tv_edition_yearPubl.text= edition.year.toString()
            tv_edition_numPages.text= edition.numPages.toString()
            tv_edition_ISBN.text= edition.ISBN
            if(edition.nameCycle?.isNotEmpty() == true)
                tv_edition_cycle.text= edition.nameCycle
            if(edition.image>0)
                iv_image.setImageResource(edition.image)
        }
        if (is_logged){
            email = mSettings!!.getString("email", "").toString()
            user = mDBHelper.findUserByEmail(email)
            basket = mDBHelper.getFavoritesByEditionForUser(edition, user)
            if (basket != null && basket!!.isFavorite){
                btn_edition_favorite.setImageResource(R.drawable.ic_favorite_on)
            }else
                btn_edition_favorite.setImageResource(R.drawable.ic_favorite_off)
        }else {
            btn_edition_favorite.visibility = ImageButton.INVISIBLE
            btn_edition_openRequest.visibility = AppCompatButton.INVISIBLE
        }

        lateinit var listLibrary:ArrayList<NumInLib>
        if (user!= null)
            listLibrary = mDBHelper.listEditionIsLib(edition.idEdition, user!!.subscriber)
        else
            listLibrary = mDBHelper.listEditionIsLib(edition.idEdition, null)
        rv_edition_libs.setHasFixedSize(true)
        rv_edition_libs.layoutManager = LinearLayoutManager(this)
        itemLibWithEdAdapter = LibWithEdAdapter(listLibrary)
        itemLibWithEdAdapter.onItemClick = { item, checkBox ->
            if(checkBox.isChecked){
                for(l in listLibrary){
                    if (!l.library.equals(item.library))
                        checkBox.isChecked = false
                }
                select = item
            }
        }
        rv_edition_libs.adapter = itemLibWithEdAdapter

        if(!listLibrary.any{it.reg}){
            btn_edition_reservation.isEnabled = false
        }
    }

    private fun initComponents() {
        tv_edition_nameBook = findViewById(R.id.tv_edition_nameBook)
        tv_edition_authors = findViewById(R.id.tv_edition_authors)
        tv_edition_discription = findViewById(R.id.tv_edition_discription)
        tv_edition_publHouse = findViewById(R.id.tv_edition_publHouse)
        tv_edition_yearPubl = findViewById(R.id.tv_edition_yearPubl)
        tv_edition_numPages = findViewById(R.id.tv_edition_numPages)
        tv_edition_ISBN = findViewById(R.id.tv_edition_ISBN)
        tv_edition_cycle = findViewById(R.id.tv_edition_cycle)
        iv_image = findViewById(R.id.iv_image)
        rv_edition_libs = findViewById(R.id.rv_edition_libs)
        btn_edition_reservation= findViewById(R.id.btn_edition_reservation)
        btn_edition_openRequest = findViewById(R.id.btn_edition_openRequest)
        btn_edition_openRequest.setOnClickListener(){
            onRequest()
        }
        btn_edition_favorite = findViewById(R.id.btn_edition_favorite)
    }

    private fun onRequest() {
        val intent = Intent(this@EditionActivity, RequestActivity::class.java)
        intent.putExtra("idEdition", edition.idEdition)
        startActivity(intent)
    }

    fun onInBasket(view: View) {
        if (user != null){
            if (select != null){
                if (select!!.reg){
                    var basket1 = Basket(edition, false, select!!.library)
                    var num:Long = mDBHelper.insertBasket(basket1, user!!, select!!.library)
                    if (num>0){
                        Toast.makeText(this, getString(R.string.insertBasketOK), Toast.LENGTH_LONG).show()
                    }
                }
            }else
                Toast.makeText(this, getString(R.string.selectedLibNull), Toast.LENGTH_LONG).show()
        }
    }
    fun onReservation(view: View) {
        if(select != null && user != null){
            val intent = Intent(this, ReservationActivity::class.java)
            intent.putIntegerArrayListExtra("list", arrayListOf<Int>(edition.idEdition))
            startActivity(intent)
        }
    }

    fun onAddFavorite(view: View) {
        if (user != null){
            var num:Long = 0
            if (basket!=null){
                if (basket!!.isFavorite)
                    btn_edition_favorite.setImageResource(R.drawable.ic_favorite_off)
                else
                    btn_edition_favorite.setImageResource(R.drawable.ic_favorite_on)
                num += mDBHelper.updateFavoriteBasket(basket!!)
                basket!!.isFavorite = !basket!!.isFavorite
            }else{
                btn_edition_favorite.setImageResource(R.drawable.ic_favorite_on)
                var basket1 = Basket(edition, true, user!!.library)
                num += mDBHelper.insertFavoriteBasket(basket1, user!!)
                basket = mDBHelper.getFavoritesByEditionForUser(edition, user)
            }
        }

    }
}