package com.example.pw3.models

class HistoryReader(var id:Int, var dateIssue:String, var dateReturn:String, var invNum:Int, var relevance:Boolean,
var library: Library, var edition:Catalog) {
}