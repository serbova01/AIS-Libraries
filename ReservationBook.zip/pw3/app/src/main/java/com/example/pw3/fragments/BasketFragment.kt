package com.example.pw3.fragments

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.*
import com.example.pw3.Adapters.ItemBasketAdapter
import com.example.pw3.Adapters.ItemCatalogAdapter
import com.example.pw3.models.Basket
import com.example.pw3.models.Reservation
import com.example.pw3.models.User

class BasketFragment : Fragment() {
//add icon: a target=_blank href=httpsicons8.comundefinedAdda icon by a target=_blank href=httpsicons8.comIcons8a
    //minus icon : https://icons8.com/icon/VyegpHl6qifs/minus

    private lateinit var rv_basket: RecyclerView
    lateinit var btn_basketFr_reservation:AppCompatButton
    lateinit var tv_numForAllReservation:TextView

    private lateinit var itemBasketAdapter: ItemBasketAdapter
    private var user: User? = null
    lateinit var mSettings: SharedPreferences
    private lateinit var mDBHelper: Server
    lateinit var basket: ArrayList<Basket>
    lateinit var selectedBasket: ArrayList<Basket>

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        requireActivity().title = getString(R.string.basket)
        initComponent(view)
        init(view)
    }

    private fun initComponent(view: View) {
        rv_basket = view.findViewById(R.id.rv_basket)
        btn_basketFr_reservation = view.findViewById(R.id.btn_basketFr_reservation)
        tv_numForAllReservation = view.findViewById(R.id.tv_numForAllReservation)

        btn_basketFr_reservation.setOnClickListener(){
            onReservationBasket()
        }
    }

    private fun init(view: View) {
        mDBHelper = Server(this.context)
        mDBHelper.connect()
        mSettings = view.context.getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        val is_logged = mSettings!!.getBoolean("is_logged", true)
        var email:String = ""
        if (is_logged){
            email = mSettings!!.getString("email", "").toString()
            user = mDBHelper.findUserByEmail(email)
            if (user != null){
                basket = mDBHelper.listBasket(user)
                selectedBasket = ArrayList()
                setRV(view)
            }
        }
    }

    private fun setRV(view: View) {
        rv_basket.setHasFixedSize(true)
        rv_basket.layoutManager = LinearLayoutManager(view.context)
        itemBasketAdapter = ItemBasketAdapter(basket)
        itemBasketAdapter.onItemClickReservation = { item ->
            openReservation(arrayListOf(item))
        }
        itemBasketAdapter.onItemClickFavorite = { item ->
            var num = mDBHelper.updateFavoriteBasket(item)
            if(num > 0)
                item.isFavorite = !item.isFavorite
        }
        itemBasketAdapter.onItemClick = { item ->
            val intent = Intent(context, EditionActivity::class.java)
            intent.putExtra("id", item.catalog.idEdition)
            startActivity(intent)
        }
        itemBasketAdapter.onItemClickDelete = { item ->
            var num:Long = mDBHelper.deleteBasket(item)
            if (num <= 0)
                Toast.makeText(context, "Не удалось удалить издание из корзины.", Toast.LENGTH_SHORT).show()
        }
        var num = 0
        itemBasketAdapter.onItemClickSelected = { item->
            if (item.isSelect){
                if(!selectedBasket.contains(item)){
                    selectedBasket.add(item)
                    num +=item.num
                }
            }else{
                if(selectedBasket.contains(item)){
                    selectedBasket.remove(item)
                    num-=item.num
                }
            }
            tv_numForAllReservation.text = num.toString()
            if (selectedBasket.size>0){
                btn_basketFr_reservation.background = view.resources.getDrawable(R.color.btn_2)
                btn_basketFr_reservation.isEnabled = num>0
            }else{
                btn_basketFr_reservation.isEnabled = false
                btn_basketFr_reservation.background = view.resources.getDrawable(R.color.btn_enableFalse)
            }
        }
        rv_basket.adapter = itemBasketAdapter
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_basket, container, false)
    }

    companion object {
        @JvmStatic
        fun newInstance() =
            BasketFragment()
    }

    fun onReservationBasket() {
        openReservation(selectedBasket)
    }

    private fun openReservation(selectedBasket: ArrayList<Basket>) {
        var arr = arrayListOf<Int>()
        selectedBasket.forEach{
            arr.add(it.id)
        }
        //for(i in 0..selectedBasket.size) {
            //arr[i] = selectedBasket[i].id
        //}
        val intent = Intent(context, ReservationActivity::class.java)
        intent.putIntegerArrayListExtra("list", arr)
        startActivity(intent)
    }
}