package com.example.pw3.profile

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.Adapters.ItemReservListAdapter
import com.example.pw3.EditionActivity
import com.example.pw3.R
import com.example.pw3.Server
import com.example.pw3.models.Reservation
import com.example.pw3.models.Subscriber
import com.example.pw3.models.User

class ReservListActivity : AppCompatActivity() {

    lateinit var tv_reservList_listNull:TextView
    lateinit var rv_reservList:RecyclerView

    private lateinit var mDBHelper: Server
    private var user: User? = null
    lateinit var mSettings: SharedPreferences
    private lateinit var itemReservListAdapter: ItemReservListAdapter
    lateinit var reservList: ArrayList<Reservation>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reserv_list)

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
        }
        this.title = getString(R.string.listReservations)

        tv_reservList_listNull = findViewById(R.id.tv_reservList_listNull)
        rv_reservList = findViewById(R.id.rv_reservList)
        init()
    }

    fun init(){
        mDBHelper = Server(this)
        mDBHelper.connect()
        mSettings = this.getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences

        var is_logged = mSettings!!.getBoolean("is_logged", false)
        if (is_logged){
            var email = mSettings!!.getString("email", "").toString()
            mSettings.edit().putString("selectedFragment", "profile").apply()
            user = mDBHelper.findUserByEmail(email)
            reservList = mDBHelper.listReservation(user)
            if (reservList.size == 0)
                tv_reservList_listNull.visibility = TextView.VISIBLE
            setRV()
        }
    }

    private fun setRV() {
        rv_reservList.setHasFixedSize(true)
        rv_reservList.layoutManager = LinearLayoutManager(this)
        itemReservListAdapter = ItemReservListAdapter(this, reservList)
        itemReservListAdapter.onItemClick = { item->
            val intent = Intent(this, EditionActivity::class.java)
            intent.putExtra("id", item.edition.idEdition)
            startActivity(intent)
        }
        rv_reservList.adapter = itemReservListAdapter
    }

}