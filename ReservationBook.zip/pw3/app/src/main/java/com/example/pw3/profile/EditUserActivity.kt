package com.example.pw3.profile

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputFilter
import android.view.View
import android.widget.*
import androidx.appcompat.app.AlertDialog
import com.example.pw3.LoginActivity
import com.example.pw3.R
import com.example.pw3.Server
import com.example.pw3.models.User
import java.lang.Exception

class EditUserActivity : AppCompatActivity() {
    private lateinit var mDBHelper: Server
    lateinit var mSettings: SharedPreferences
    private var user: User? = null

    lateinit var lv_editProfile_changePass: LinearLayout
    lateinit var et_edit_oldPass: EditText
    lateinit var et_edit_newPass: EditText
    lateinit var et_edit_login:EditText
    lateinit var et_edit_email:EditText
    lateinit var cb_edit_isEditPass:CheckBox


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_user)
        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
        }

        this.title = getString(R.string.editProfile)

        init()
    }

    fun init(){
        lv_editProfile_changePass = findViewById(R.id.lv_editProfile_changePass)
        et_edit_oldPass = findViewById(R.id.et_edit_oldPass)
        et_edit_newPass = findViewById(R.id.et_edit_newPass)
        et_edit_login = findViewById(R.id.et_edit_login)
        et_edit_email = findViewById(R.id.et_edit_email)
        cb_edit_isEditPass = findViewById(R.id.cb_edit_isEditPass)
        cb_edit_isEditPass.setOnClickListener(){
            onOpenPanelEditPass()
        }

        val filterLogin =
            InputFilter { source, start, end, dest, dstart, dend ->
                for (i in start until end) {
                    if (!Character.isLetterOrDigit(source[i])) {
                        return@InputFilter ""
                    }
                }
                null
            }
        et_edit_login.filters = arrayOf(filterLogin)

        val filterPass =
            InputFilter { source, start, end, dest, dstart, dend ->
                for (i in start until end) {
                    if (Character.isWhitespace(source[i])) {
                        return@InputFilter ""
                    }
                }
                null
            }
        et_edit_newPass.filters = arrayOf(filterPass)
        et_edit_oldPass.filters = arrayOf(filterPass)

        mDBHelper = Server(this)
        mDBHelper.connect()
        mSettings = getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        val is_logged = mSettings!!.getBoolean("is_logged", false)
        if (is_logged){
            var email = mSettings!!.getString("email", "").toString()
            user = mDBHelper.findUserByEmail(email)
        }
        et_edit_login.setText(user?.login ?: "")
        et_edit_email.setText(user?.email ?: "")
    }

    private fun checkPass(): Boolean {
        if (et_edit_newPass.text.trim().isEmpty()){
            Toast.makeText(this, getString(R.string.newPassNull), Toast.LENGTH_SHORT).show()
            return false
        }
        if (et_edit_oldPass.text.trim().isEmpty()){
            Toast.makeText(this, getString(R.string.oldPassNull), Toast.LENGTH_SHORT).show()
            return false
        }
        if (!mDBHelper.checkPassword(user, et_edit_oldPass.text.toString().trim())){
            Toast.makeText(this, getString(R.string.falseOldPass), Toast.LENGTH_SHORT).show()
            return false
        }

        if (!et_edit_oldPass.text.toString().trim().equals(et_edit_oldPass.text.toString()) &&
            !et_edit_newPass.toString().trim().equals(et_edit_newPass.text.toString())){
            Toast.makeText(this, getString(R.string.is_inOldPass), Toast.LENGTH_SHORT).show()
            return false
        }
        return true
    }

    fun onOpenPanelEditPass() {
        if (cb_edit_isEditPass.isChecked){
            lv_editProfile_changePass.visibility = GridLayout.VISIBLE
        }else
            lv_editProfile_changePass.visibility = GridLayout.INVISIBLE
    }

    fun onSaveEdits(view: View) {
        createAlertForYesForEdits()
    }

    private fun createAlertForYesForEdits(){
        val alertDialog = AlertDialog.Builder(this@EditUserActivity)
        alertDialog.setTitle(R.string.alertTitle_saveUser)
        var text = getString(R.string.alertText_saveUser)

        alertDialog.setMessage(text)
        alertDialog.setIcon(R.mipmap.ic_launcher)
        alertDialog.setPositiveButton("YES"){dialog, id->
            saveUserData()
        }
        alertDialog.setNegativeButton("NO"){dialog, id->

        }

        alertDialog.show()
    }

    fun saveUserData():Boolean{
        var flag = false
        if (!user?.email.equals(et_edit_email.text.toString())){
            var userCheck = mDBHelper.findUserByEmail(et_edit_email.text.toString())
            if (userCheck == null || userCheck.id != user!!.id){
                try {
                    var num : Long = mDBHelper.updateEmail(user, et_edit_email.text.toString())
                    flag=true
                }catch (ex:Exception){
                    Toast.makeText(this, "Смена email не удалась.\n error: " + ex.toString(), Toast.LENGTH_SHORT).show()
                    flag = false
                }
            }else
            {
                Toast.makeText(this, getString(R.string.emailReg), Toast.LENGTH_SHORT).show()
                return false
            }
        }
        if (!user?.login.equals(et_edit_login.text.toString())){
            var userCheck = mDBHelper.findUserByLogin(et_edit_login.text.toString())
            if ( userCheck == null || userCheck.id != user!!.id){
                var num : Long = mDBHelper.updateLogin(user, et_edit_login.text.toString())
                if (num <= 0){
                    Toast.makeText(this, "Смена логина не удалась.", Toast.LENGTH_SHORT).show()
                    flag = false
                }
                else
                    flag=true
            }else
            {
                Toast.makeText(this, getString(R.string.loginReg), Toast.LENGTH_SHORT).show()
                return false
            }
        }
        if (cb_edit_isEditPass.isChecked && checkPass()){
            var num : Long = mDBHelper.updatePassword(user, et_edit_newPass.text.toString().trim())
            if (num <= 0){
                Toast.makeText(this, "Смена пароля не удалась.", Toast.LENGTH_SHORT).show()
                flag = false
            }
            else{
                Toast.makeText(this, getString(R.string.passChanged), Toast.LENGTH_SHORT).show()
                flag=true
            }
        }else {
            if(cb_edit_isEditPass.isChecked) return false
        }
        if (flag){
            var editor = mSettings.edit()
            editor.putString("email", " ").apply()
            editor.putBoolean("is_logged", false).apply()
            val intent =
                Intent(this@EditUserActivity, LoginActivity::class.java)
            startActivity(intent)
        }
        return flag
    }
}