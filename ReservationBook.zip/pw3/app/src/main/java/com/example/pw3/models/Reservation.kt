package com.example.pw3.models

import java.sql.Date

class Reservation (var id:Int, var dateForm:String, var dateReserv:String, var library: Library,
    var edition:Catalog, var status:String) {

}