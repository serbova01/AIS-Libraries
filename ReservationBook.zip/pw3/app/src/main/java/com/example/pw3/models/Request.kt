package com.example.pw3.models

class Request(
    var id: Int,
    var status: String,
    var library: Library,
    var catalog: Catalog
){
}