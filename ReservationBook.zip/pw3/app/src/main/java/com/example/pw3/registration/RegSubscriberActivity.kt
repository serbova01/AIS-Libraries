package com.example.pw3.registration

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputFilter
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.example.pw3.MainActivity
import com.example.pw3.R
import com.example.pw3.Server
import com.example.pw3.models.Library
import com.example.pw3.models.Subscriber
import com.example.pw3.models.User

class RegSubscriberActivity : AppCompatActivity() {

    lateinit var et_firstName: EditText
    lateinit var et_secondName: EditText
    lateinit var et_lastName: EditText
    lateinit var et_phoneNumber: EditText
    lateinit var et_address: EditText
    lateinit var tv_next: TextView

    private lateinit var mDBHelper: Server
    lateinit var mSettings: SharedPreferences
    var selectedLibId:Int = 0
    var user: User = User()
    var phNumber = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_reg_subscriber)

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
        }
        val bundle = intent.extras
        if (bundle != null){
            user = User(bundle.getString("user.login"), bundle.getString("user.password"),
                bundle.getString("user.email"), bundle.getString("user.role"))
            phNumber = bundle.getString("phNumber").toString()
            selectedLibId = bundle.getInt("selectedLib.id")
        }

        //selectedLib = intent.extras?.get("selectedLib") as Library
        this.title = getString(R.string.title_regSubscriber)
        //user = intent.extras?.get("user") as User

        init()
    }

    fun init(){
        et_firstName = findViewById(R.id.et_firstName)
        et_secondName = findViewById(R.id.et_secondName)
        et_lastName = findViewById(R.id.et_lastName)
        et_phoneNumber = findViewById(R.id.et_phoneNumber)
        et_address = findViewById(R.id.et_address)
        tv_next = findViewById(R.id.tv_next)
        et_phoneNumber.setText(phNumber)
        et_phoneNumber.isEnabled = false

        mDBHelper = Server(this)
        mDBHelper.connect()

        val filterName = InputFilter { source, start, end, dest, dstart, dend ->
                for (i in start until end) {
                    if (!Character.isLetter(source[i])) {
                        return@InputFilter ""
                    }
                }
                null
            }
        et_firstName.filters = arrayOf(filterName)
        et_secondName.filters = arrayOf(filterName)
        et_lastName.filters = arrayOf(filterName)
    }

    fun onClick(v: View){
        if (checkNull()){
            mSettings = getSharedPreferences("my_storage", Context.MODE_PRIVATE)

            var num:Long = mDBHelper.insertSubscriber(user, Subscriber(et_firstName.text.toString().trim(),
            et_secondName.text.toString().trim(), et_lastName.text.toString().trim(), user.email, phNumber,
            et_address.text.toString()), selectedLibId)

            if (num > 0){
                val editor = mSettings.edit()
                editor.putBoolean("is_logged", true).apply()
                editor.putString("email", user.email).apply()

                val intent = Intent(this@RegSubscriberActivity, MainActivity::class.java)
                startActivity(intent)
            }else{
                Toast.makeText(this, "Не удалось добавить нового абонента", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun checkNull(): Boolean {
        return checkAddress(et_address.text.toString())

        if (et_firstName.text.isNotEmpty() and et_secondName.text.isNotEmpty() and et_phoneNumber.text.isNotEmpty() and
            et_address.text.isNotEmpty()){
            return true
        }else{
            if (et_firstName.text.isEmpty())
                Toast.makeText(this, getString(R.string.firstNameNull), Toast.LENGTH_SHORT).show()
            else{
                if (et_secondName.text.isEmpty())
                    Toast.makeText(this, getString(R.string.secondNameNull), Toast.LENGTH_SHORT).show()
                else{
                    if (et_address.text.isEmpty())
                        Toast.makeText(this, getString(R.string.addressNull), Toast.LENGTH_SHORT).show()
                    else{
                        if (et_phoneNumber.text.isEmpty())
                            Toast.makeText(this, getString(R.string.phoneNumberNull), Toast.LENGTH_SHORT).show()
                    }
                }
            }
        }
        return false
    }

    private fun checkAddress(address: String): Boolean {
        var arr = address.split(",")
        if (arr.count() < 4){
            Toast.makeText(this, getString(R.string.addressInCorrect), Toast.LENGTH_SHORT).show()
            return false
        }else{
            return true
        }
    }

}