package com.example.pw3.models

class Author (firstname:String, secondname:String, lastname: String?){
    var firstname = firstname
    var secondname = secondname
    var lastname:String? = lastname
    var shorName:String = setShortName()

    private fun setShortName(): String {
        var shorName = firstname + " " + secondname[0] + "."
        if (lastname?.isNotEmpty() == true)
            shorName += " " + lastname!![0] + "."

        return shorName
    }
}