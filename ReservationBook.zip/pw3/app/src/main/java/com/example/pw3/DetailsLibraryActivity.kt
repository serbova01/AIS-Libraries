package com.example.pw3

import android.content.Context
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import com.example.pw3.models.Library
import com.example.pw3.models.User

class DetailsLibraryActivity : AppCompatActivity() {

    lateinit var tv_detLib_name:TextView
    lateinit var tv_detLib_email:TextView
    lateinit var tv_detLib_cityNumber:TextView
    lateinit var tv_detLib_address:TextView

    private lateinit var mDBHelper: Server
    lateinit var mSettings: SharedPreferences
    lateinit var user: User
    lateinit var library:Library

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_details_library)

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
        }
        this.title = getString(R.string.detailsLib)

        tv_detLib_name = findViewById(R.id.tv_detLib_name)
        tv_detLib_email = findViewById(R.id.tv_detLib_email)
        tv_detLib_cityNumber = findViewById(R.id.tv_detLib_cityNumber)
        tv_detLib_address = findViewById(R.id.tv_detLib_address)

        library = Library()
        library.id = intent.getIntExtra("idLib", 0)

        init()

    }

    fun init(){
        mDBHelper = Server(this)
        mDBHelper.connect()
        mSettings = this.getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        var is_logged = mSettings!!.getBoolean("is_logged", false)
        var email = ""
        if (is_logged){
            email = mSettings!!.getString("email", "").toString()
            user = mDBHelper.findUserByEmail(email)
            library = mDBHelper.findLibraryById(library.id)

            tv_detLib_name.setText(library.nameL)
            tv_detLib_cityNumber.text = library.cityPhNum
            tv_detLib_email.text = library.email
            tv_detLib_address.text = library.address
        }

    }
}
