package com.example.pw3.Adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.R
import com.example.pw3.models.Catalog


class ItemFavoritesAdapter(val favorites: ArrayList<Catalog>) :
    RecyclerView.Adapter<ItemFavoritesAdapter.ItemFavoritesViewHolder>(){

    var onItemClick: ((Catalog) -> Unit)? = null
    var onItemClickBasket: ((Catalog) -> Unit)? = null
    var onItemClickDelete: ((Catalog) -> Unit)? = null

    inner class ItemFavoritesViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val imageView : ImageView = itemView.findViewById(R.id.iv_favorites_imageEd)
        val textView_title : TextView = itemView.findViewById(R.id.tv_favorites_nameItem)
        val textView_text : TextView = itemView.findViewById(R.id.tv_favorites_discriptionItem)
        val btn_delete:ImageButton = itemView.findViewById(R.id.ib_favorites_delete)
        val btn_basket:ImageButton = itemView.findViewById(R.id.ib_favorites_basket)
        init {
            itemView.setOnClickListener {
                onItemClick?.invoke(favorites[adapterPosition])
            }
            btn_basket.setOnClickListener(){
                onItemClickBasket?.invoke(favorites[adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemFavoritesViewHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.item_favorites_layout, parent, false)

        return ItemFavoritesViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemFavoritesViewHolder, position: Int) {
        val item = favorites[position]
        item.image?.let { holder.imageView.setImageResource(it) }
        holder.textView_title.text = item.nameBook
        holder.textView_text.text = item.getShortText()
        holder.btn_delete.setOnClickListener(){
            favorites.remove(item)
            onItemClickDelete?.invoke(item)
        }
    }

    override fun getItemCount(): Int {
        return favorites.size
    }
}