package com.example.pw3.profile

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.Adapters.ItemRequestListAdapter
import com.example.pw3.Adapters.ItemReservListAdapter
import com.example.pw3.EditionActivity
import com.example.pw3.R
import com.example.pw3.Server
import com.example.pw3.models.Request
import com.example.pw3.models.User

class RequestListActivity : AppCompatActivity() {

    lateinit var tv_reqList_listNull:TextView
    lateinit var rv_reqList:RecyclerView

    private lateinit var mDBHelper: Server
    private var user: User? = null
    lateinit var mSettings: SharedPreferences
    lateinit var requestList:ArrayList<Request>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_request_list)

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
        }
        this.title = getString(R.string.listRequest)

        tv_reqList_listNull = findViewById(R.id.tv_reqList_listNull)
        rv_reqList = findViewById(R.id.rv_reqList)

        init()
    }

    fun init(){
        mDBHelper = Server(this)
        mDBHelper.connect()
        mSettings = this.getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences

        var is_logged = mSettings!!.getBoolean("is_logged", false)
        if (is_logged){
            var email = mSettings!!.getString("email", "").toString()
            user = mDBHelper.findUserByEmail(email)
            mSettings.edit().putString("selectedFragment", "profile").apply()
            requestList = mDBHelper.listRequest(user!!.subscriber)
            if (requestList.size > 0){
                rv_reqList.setHasFixedSize(true)
                rv_reqList.layoutManager = LinearLayoutManager(this)
                var itemRequestListAdapter = ItemRequestListAdapter(requestList)
                itemRequestListAdapter.onItemClick = { item ->
                    val intent = Intent(this, EditionActivity::class.java)
                    intent.putExtra("id", item.catalog.idEdition)
                    startActivity(intent)
                }
                rv_reqList.adapter = itemRequestListAdapter
            }else
                tv_reqList_listNull.visibility = TextView.VISIBLE
        }
    }
}