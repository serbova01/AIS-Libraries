package com.example.pw3.profile

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.InputFilter
import android.view.View
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.example.pw3.ProfileActivity
import com.example.pw3.R
import com.example.pw3.Server
import com.example.pw3.models.Subscriber
import com.example.pw3.models.User

class EditSubscriberActivity : AppCompatActivity() {

    lateinit var et_edit_firstname:EditText
    lateinit var et_edit_secondname:EditText
    lateinit var et_edit_lastname:EditText
    lateinit var et_edit_phNumber:EditText
    lateinit var et_edit_district:EditText
    lateinit var et_edit_city:EditText
    lateinit var et_edit_street:EditText
    lateinit var et_edit_house:EditText
    lateinit var et_edit_flat:EditText
    lateinit var tv_edit_errorPhNum:TextView

    private lateinit var mDBHelper: Server
    lateinit var mSettings: SharedPreferences
    private var user: User? = null
    var maskPhNum = "+0 (000) 000-00-00"


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_edit_subscriber)

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
        }
        this.title = getString(R.string.editDataSubs)

        init()
    }

    fun init(){
        iniComponents()

        mDBHelper = Server(this)
        mDBHelper.connect()
        mSettings = getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        val is_logged = mSettings!!.getBoolean("is_logged", false)
        if (is_logged){
            var email = mSettings!!.getString("email", "").toString()
            user = mDBHelper.findUserByEmail(email)
        }
        et_edit_firstname.setText(user?.subscriber?.firstName ?: "")
        et_edit_secondname.setText(user?.subscriber?.secondName ?: "")
        et_edit_lastname.setText(user?.subscriber?.lastName ?: "")
        et_edit_phNumber.setText(user?.subscriber?.phoneNumber ?: "")
        et_edit_district.setText(user?.subscriber?.district ?: "")
        et_edit_city.setText(user?.subscriber?.city ?: "")
        et_edit_street.setText(user?.subscriber?.street ?: "")
        et_edit_house.setText(user?.subscriber?.house ?: "")
        et_edit_flat.setText(user?.subscriber?.flat ?: "")

        val filterPhNumber = InputFilter { source, start, end, dest, dstart, dend ->
            for (i in start until end) {
                var j = et_edit_phNumber.text.toString().length

                if (!((Character.isDigit(source[i]) &&
                            Character.isDigit(maskPhNum[j])) ||
                            source[i].toString().equals(maskPhNum[j].toString()) ||
                            (j == 1 && source[i].equals("7")))) {
                    tv_edit_errorPhNum.visibility = TextView.VISIBLE
                    return@InputFilter ""
                }
            }
            null
        }
        et_edit_phNumber.filters = arrayOf(filterPhNumber)

    }

    private fun iniComponents() {
        et_edit_firstname = findViewById(R.id.et_edit_firstname)
        et_edit_secondname = findViewById(R.id.et_edit_secondname)
        et_edit_lastname = findViewById(R.id.et_edit_lastname)
        et_edit_phNumber = findViewById(R.id.et_edit_phNumber)
        et_edit_district = findViewById(R.id.et_edit_district)
        et_edit_city = findViewById(R.id.et_edit_city)
        et_edit_street = findViewById(R.id.et_edit_street)
        et_edit_house = findViewById(R.id.et_edit_house)
        et_edit_flat = findViewById(R.id.et_edit_flat)
        tv_edit_errorPhNum = findViewById(R.id.tv_edit_errorPhNum)
        val filterName = InputFilter { source, start, end, dest, dstart, dend ->
            for (i in start until end) {
                if (!Character.isLetter(source[i])) {
                    return@InputFilter ""
                }
            }
            null
        }
        et_edit_firstname.filters = arrayOf(filterName)
        et_edit_secondname.filters = arrayOf(filterName)
        et_edit_lastname.filters = arrayOf(filterName)
        et_edit_district.filters = arrayOf(filterName)


    }

    fun onSaveEditsSubs(view: View) {
        var subscriber = mDBHelper.findSubscriberByPhNumber(et_edit_phNumber.text.toString())
        if (subscriber == null || subscriber!!.id == user!!.subscriber!!.id){
            var num:Long = mDBHelper.editSubscriber(setSubscriber())
            if (num < 1)
                Toast.makeText(this, "Не удалось сохранить данные", Toast.LENGTH_SHORT).show()
            else{
                val intent = Intent(this@EditSubscriberActivity, ProfileActivity::class.java)
                startActivity(intent)
            }
        }else{
            Toast.makeText(this, getString(R.string.phoneNumReg), Toast.LENGTH_SHORT).show()
        }

    }

    private fun setSubscriber(): Subscriber {
        var subscriber = Subscriber()
        if (et_edit_firstname.text.isNotEmpty())
            subscriber.firstName = et_edit_firstname.text.toString()
        else
            subscriber.firstName = user?.subscriber?.firstName ?: ""

        if (et_edit_secondname.text.isNotEmpty())
            subscriber.secondName= et_edit_secondname.text.toString()
        else
            subscriber.secondName = user?.subscriber?.secondName ?: ""

        if (et_edit_lastname.text.isNotEmpty())
            subscriber.lastName = et_edit_lastname.text.toString()
        else
            subscriber.lastName = user?.subscriber?.lastName ?: ""
        if (et_edit_phNumber.text.isNotEmpty())
            subscriber.phoneNumber = et_edit_phNumber.text.toString()
        else
            subscriber.phoneNumber = user?.subscriber?.phoneNumber ?: ""

        var address = setAddress(arrayListOf<EditText>(et_edit_district, et_edit_city, et_edit_street, et_edit_house, et_edit_flat),
            user?.subscriber?.address?.split(",") as ArrayList<String> )

        subscriber.setAddress1(address)

        subscriber.id = user!!.subscriber?.id ?: 0

        return subscriber
    }

    private fun setAddress(listNewData: ArrayList<EditText>, listOldData: ArrayList<String>): String {
        var str = ""
        for(i in listNewData.indices){
            if (i < listOldData.count()-1){
                if (listNewData[i].text.isNotEmpty()){
                    str+=listNewData[i].text.toString() + ", "
                }else
                    str+=listOldData[i] + ", "
            }else{
                if (listNewData[i].text.isNotEmpty()){
                    str+=listNewData[i].text.toString()
                }else{
                    if(i < listOldData.count())
                        str+=listOldData[i]
                }
                if (i + 1 != listNewData.count() && listNewData[i+1].text.isNotEmpty())
                    str+=", "
            }
        }
        return str
    }

}