package com.example.pw3.models

class ReservationPrewie(var library: Library, var list: ArrayList<Basket>) {
}