package com.example.pw3.models

import java.net.Inet4Address

class Subscriber (){
    var firstName = ""
    var secondName = ""
    var lastName:String? = ""
    var phoneNumber = ""
    var address = ""
    var district = ""
    var city = ""
    var street = ""
    var house = ""
    var flat = ""
    var emailS:String? = ""
    var id = 0
    var listSubsNum = ArrayList<SubsNum>()
    constructor(id:Int, firstName:String, secondName:String, lastName:String?, emailS:String?,
                phoneNumber:String, address: String) : this(firstName, secondName, lastName, emailS,
        phoneNumber, address){
        this.id = id
        this.firstName = firstName
        this.secondName = secondName
        this.lastName = lastName
        this.emailS = emailS
        this.phoneNumber = phoneNumber
        setAddress1(address)
    }
    fun setAddress1(address:String){
        this.address = address
        var arr = address.split(",")
        this.district = arr[0]
        this.city = arr[1]
        this.street = arr[2]
        this.house = arr[3]
        this.flat = checkIsFlat(arr)
    }

    constructor(firstName:String, secondName:String, lastName:String?, emailS:String?,
                phoneNumber:String, address:String ) : this(){
        this.id = id
        this.firstName = firstName
        this.secondName = secondName
        this.lastName = lastName
        this.emailS = emailS
        this.phoneNumber = phoneNumber
        setAddress1(address)
    }

    private fun checkIsFlat(arrAddress: List<String>): String {
        if (arrAddress.size > 4){
            return arrAddress[4]
        }
        return ""
    }


}
