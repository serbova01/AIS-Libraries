package com.example.pw3.Adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.NumberPicker
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.R
import com.example.pw3.models.Basket
import com.example.pw3.models.Reservation

class ItemReservationAdapter(var context:Context, var list:ArrayList<Basket>) :
    RecyclerView.Adapter<ItemReservationAdapter.ItemReservationHolder>(){

    inner class ItemReservationHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val imageView : ImageView = itemView.findViewById(R.id.iv_reservationItem)
        val tv_title : TextView = itemView.findViewById(R.id.tv_reservationItem_title)
        val tv_discription : TextView = itemView.findViewById(R.id.tv_reservationItem_content)
        val button:ImageButton = itemView.findViewById(R.id.btn_reservationItem_delete)
        val numberPicker:NumberPicker = itemView.findViewById(R.id.np_reservationItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemReservationHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.item_reserv_library, parent, false)
        return ItemReservationHolder(view)
    }

    override fun onBindViewHolder(holder: ItemReservationHolder, position: Int) {
        val item = list[position]
        item.catalog.image?.let { holder.imageView.setImageResource(it) }
        holder.tv_title.text = item.catalog.nameBook
        holder.tv_discription.text = item.catalog.getShortText()
        holder.button.setOnClickListener {
            list.remove(item)
            notifyItemRemoved(position)
        }
        holder.numberPicker.value = item.num
        holder.numberPicker.minValue = 1
        holder.numberPicker.maxValue = item.num
        holder.numberPicker.setOnValueChangedListener { picker, oldVal, newVal ->
            item.num = newVal
            holder.numberPicker.value = item.num
            holder.numberPicker.minValue = 1
            holder.numberPicker.maxValue = item.num
        }
    }

    override fun getItemCount(): Int {
        return list.size
    }
}