package com.example.pw3.Adapters

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.R
import com.example.pw3.models.Basket
import com.example.pw3.models.ReservationPrewie

class ItemReservWithLibAdapter(var context:Context ,var list:ArrayList<ReservationPrewie>):
    RecyclerView.Adapter<ItemReservWithLibAdapter.ItemReservWithLibHolder>() {

    inner class ItemReservWithLibHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val tv_title : TextView = itemView.findViewById(R.id.tv_reservWithLibItem)
        val recyclerView : RecyclerView = itemView.findViewById(R.id.rv_reservWithLibItem)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemReservWithLibHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.item_reserv_with_library_layout, parent, false)
        return ItemReservWithLibHolder(view)
    }

    override fun onBindViewHolder(holder: ItemReservWithLibHolder, position: Int) {
        var item = list[position]
        var text:String = holder.tv_title.text.toString()
        text+= "\t" + item.library.nameL
        holder.tv_title.text = text
        holder.recyclerView.setHasFixedSize(true)
        holder.recyclerView.layoutManager =
            LinearLayoutManager(context, LinearLayoutManager.HORIZONTAL, false)
        var itemReservationAdapter:ItemReservationAdapter =
            ItemReservationAdapter(context, item.list)
        holder.recyclerView.adapter = itemReservationAdapter
    }

    override fun getItemCount(): Int {
        return list.size
    }
}