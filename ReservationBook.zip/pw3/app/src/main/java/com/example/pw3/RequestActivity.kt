package com.example.pw3

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.Adapters.ItemLibRegSusbAdapter
import com.example.pw3.Adapters.LibWithEdAdapter
import com.example.pw3.models.*

class RequestActivity : AppCompatActivity() {

    lateinit var iv_request_imageBook:ImageView
    lateinit var tv_request_nameBook:TextView
    lateinit var tv_request_contentBook:TextView
    lateinit var rv_request_libs:RecyclerView

    lateinit var mSettings: SharedPreferences
    private lateinit var mDBHelper: Server
    lateinit var user: User
    lateinit var edition:Catalog
    lateinit var listInfo:ArrayList<SubsNum>
    var select:Library? = null
    lateinit var itemLibRegSusbAdapter:ItemLibRegSusbAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_request)

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
        }
        this.title = getString(R.string.formRequest)

        init()
    }

    fun init(){
        initComponents()
        mDBHelper = Server(this)
        mDBHelper.connect()
        mSettings = this.getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        var is_logged = mSettings!!.getBoolean("is_logged", false)
        var email = ""
        if (is_logged){
            email = mSettings!!.getString("email", "").toString()
            user = mDBHelper.findUserByEmail(email)
            if (user != null){
                var id = intent.getIntExtra("idEdition", 0)
                edition = mDBHelper.findEditionById(id)
                if (edition!= null){
                    iv_request_imageBook.setImageResource(edition.image)
                    tv_request_nameBook.text = edition.nameBook
                    tv_request_contentBook.text = edition.getShortText()

                    listInfo = mDBHelper.listSubsNums(user.subscriber)
                    if (listInfo.size > 0){
                        listInfo.forEach{it.isSelect = it.library.id == user.library.id}
                        select = user.library

                        rv_request_libs.setHasFixedSize(true)
                        rv_request_libs.layoutManager = LinearLayoutManager(this)
                        itemLibRegSusbAdapter = ItemLibRegSusbAdapter(listInfo)
                        itemLibRegSusbAdapter.onItemChecked = { item, checkBox ->
                            onChecked(checkBox,item)
                        }
                        rv_request_libs.adapter = itemLibRegSusbAdapter
                    }else{
                        val builder = AlertDialog.Builder(this)
                        builder.setTitle(getString(R.string.waring))
                            .setMessage(getString(R.string.listLibsForEditionNull))
                            .setPositiveButton(getString(R.string.toReturn)) { dialog, id ->
                                val intent = Intent(this@RequestActivity, EditionActivity::class.java)
                                intent.putExtra("id", edition.idEdition)
                                startActivity(intent)
                            }
                        builder.create()
                    }
                }
            }
        }
    }

    private fun onChecked(checkBox: CheckBox, item: SubsNum) {
        if (checkBox.isChecked){
            itemLibRegSusbAdapter.setActiveQuery(item)
            select = item.library
        }
    }

    private fun initComponents() {
        iv_request_imageBook = findViewById(R.id.iv_request_imageBook)
        tv_request_nameBook = findViewById(R.id.tv_request_nameBook)
        tv_request_contentBook = findViewById(R.id.tv_request_contentBook)
        rv_request_libs = findViewById(R.id.rv_request_libs)
    }

    fun onSendRequest(view: View) {
        if (select != null){
            val num:Long = mDBHelper.insertRequest(select!!, edition, user.subscriber)
            if (num>0){
                val intent = Intent(this@RequestActivity, MainActivity::class.java)
                startActivity(intent)
            }
        }else
            Toast.makeText(this, getString(R.string.selectedLibNull), Toast.LENGTH_LONG).show()
    }
}