package com.example.pw3.Adapters

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.R
import com.example.pw3.Server
import com.example.pw3.models.Reservation

class ItemReservListAdapter(var context:Context, var list:ArrayList<Reservation>)  :
    RecyclerView.Adapter<ItemReservListAdapter.ItemReservListHolder>(){

    var onItemClick: ((Reservation) -> Unit)? = null
    var onItemClickDelete: ((Boolean, Reservation) -> Unit)? = null

    inner class ItemReservListHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val imageView : ImageView = itemView.findViewById(R.id.iv_reservItem_imageEd)
        val tv_title : TextView = itemView.findViewById(R.id.tv_reservItem_titleBook)
        val tv_dateForm : TextView = itemView.findViewById(R.id.tv_reservItem_dateForm)
        val tv_dateReserv : TextView = itemView.findViewById(R.id.tv_reservItem_dateReserv)
        val tv_libName : TextView = itemView.findViewById(R.id.tv_reservItem_libName)
        val tv_libAddress : TextView = itemView.findViewById(R.id.tv_reservItem_libAddress)
        val tv_discription : TextView = itemView.findViewById(R.id.tv_reservItem_discriptionBook)
        val tv_status:TextView = itemView.findViewById(R.id.tv_reservItem_rStatus)
        val button:AppCompatButton = itemView.findViewById(R.id.btn_reservItem_delete)
        init {
            itemView.setOnClickListener {
                onItemClick?.invoke(list[adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemReservListHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.item_reservation_layout, parent, false)
        return ItemReservListHolder(view)
    }

    override fun onBindViewHolder(holder: ItemReservListHolder, position: Int) {
        val item = list[position]
        item.edition.image?.let { holder.imageView.setImageResource(it) }
        holder.tv_title.text = item.edition.nameBook
        holder.tv_discription.text = item.edition.getShortText()
        holder.tv_dateForm.text = item.dateForm
        holder.tv_dateReserv.text = item.dateReserv
        holder.tv_libName.text = item.library.nameL
        holder.tv_libAddress.text = item.library.address
        holder.tv_status.text = item.status
        if (item.status.equals("готово к выдаче")){
            holder.tv_status.setTextColor(Color.GREEN)
        }else
            holder.tv_status.setTextColor(Color.RED)

        holder.button.setOnClickListener(){
            createAlert(item)

        }
    }

    override fun getItemCount(): Int {
        return list.size
    }
    private fun createAlert(reservation: Reservation){
        val alertDialog = AlertDialog.Builder(context)
        alertDialog.setTitle(R.string.deleteReservation)

        alertDialog.setMessage(R.string.confimDeleteReservation)
        alertDialog.setIcon(R.mipmap.ic_launcher)
        alertDialog.setPositiveButton("Удалить"){dialog, id->
            var mDBHelper = Server(context)
            mDBHelper.connect()
            var num:Long = mDBHelper.deleteReservation(reservation)
            if (num > 0)
                list.remove(reservation)
        }
        alertDialog.setNegativeButton("Отмена"){dialog, id->
            dialog.dismiss()
        }

        alertDialog.show()
    }

}