package com.example.pw3.Adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.R
import com.example.pw3.models.SubsNum

class ItemLibForProfileAdapter (var list:ArrayList<SubsNum>) :
    RecyclerView.Adapter<ItemLibForProfileAdapter.ItemLibForProfileHolder>(){
    var onItemClick: ((SubsNum) -> Unit)? = null
    var onItemCheck: ((SubsNum, CheckBox) -> Unit)? = null

    inner class ItemLibForProfileHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val checkBox:CheckBox = itemView.findViewById(R.id.cb_libForProfileItem)
        val textView_name : TextView = itemView.findViewById(R.id.tv_libForProfileItem_name)
        val textView_address : TextView = itemView.findViewById(R.id.tv_libForProfileItem_address)
        val textView_num : TextView = itemView.findViewById(R.id.tv_libForProfileItem_num)
        val textView_details : TextView = itemView.findViewById(R.id.tv_libForProfileItem_details)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemLibForProfileHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_lib_for_profile_layout, parent, false)
        return ItemLibForProfileHolder(view)
    }

    override fun onBindViewHolder(holder: ItemLibForProfileHolder, position: Int) {
        var item:SubsNum = list[position]

        holder.textView_num.text = item.activeNumber.toString()
        holder.textView_name.text = item.library.nameL
        holder.textView_address.text = item.library.address
        holder.textView_details.setOnClickListener(){
            onItemClick?.invoke(item)
        }
        holder.checkBox.setOnClickListener(){
            onItemCheck?.invoke(item, holder.checkBox)
        }
        holder.checkBox.isChecked = item.isSelect
    }

    override fun getItemCount(): Int {
        return list.size
    }

    fun setActiveQuery(item: SubsNum) {
        for (l in list)
            l.isSelect = l.library.id == item.library.id

        notifyDataSetChanged()
    }
}