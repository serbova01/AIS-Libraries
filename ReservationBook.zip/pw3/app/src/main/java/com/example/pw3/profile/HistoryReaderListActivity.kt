package com.example.pw3.profile

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.Adapters.ItemDelayedHRAdapter
import com.example.pw3.Adapters.ItemHRAdapter
import com.example.pw3.Adapters.ItemIssuedHRAdapter
import com.example.pw3.EditionActivity
import com.example.pw3.R
import com.example.pw3.Server
import com.example.pw3.models.HistoryReader
import com.example.pw3.models.User
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter


class HistoryReaderListActivity : AppCompatActivity() {

    lateinit var ll_hr_delayedBookList:LinearLayout
    lateinit var rv_hr_delayedBookList:RecyclerView
    lateinit var ll_hr_issuedBookList:LinearLayout
    lateinit var rv_hr_issuedBookList:RecyclerView
    lateinit var ll_hrBookList:LinearLayout
    lateinit var rv_hr_returnedBookList:RecyclerView
    lateinit var tv_hr_listNull:TextView
    lateinit var tv_hr_selectAllIB:TextView
    lateinit var tv_hr_selectAllDB:TextView

    private lateinit var mDBHelper: Server
    private var user: User? = null
    lateinit var mSettings: SharedPreferences
    lateinit var delayedList: ArrayList<HistoryReader>
    lateinit var selectDelayedList: ArrayList<HistoryReader>
    lateinit var issuedList: ArrayList<HistoryReader>
    lateinit var selectIssuedList: ArrayList<HistoryReader>
    lateinit var historyReader: ArrayList<HistoryReader>

    @RequiresApi(Build.VERSION_CODES.O)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_history_reader_list)

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
        }
        this.title = getString(R.string.historyReader)

        initComponents()
        init()
    }

    fun init(){
        mDBHelper = Server(this)
        mDBHelper.connect()
        mSettings = this.getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences

        var is_logged = mSettings!!.getBoolean("is_logged", false)
        if (is_logged){
            var email = mSettings!!.getString("email", "").toString()
            mSettings.edit().putString("selectedFragment", "profile").apply()
            user = mDBHelper.findUserByEmail(email)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                setAddapters()
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun setAddapters() {
        selectIssuedList = ArrayList()
        selectDelayedList = ArrayList()
        var date = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))
        delayedList = mDBHelper.listHR(user, " hrRelevance = 1 and hrDateReturn <= '$date'")
        if (delayedList.size == 0)
            ll_hr_delayedBookList.setLayoutParams(
                LinearLayout.LayoutParams(rv_hr_delayedBookList.layoutParams.width, 0))
        else{
            setDelayedHRAddapter()
        }
        issuedList = mDBHelper.listHR(user, " hrRelevance = 1 and hrDateReturn > '$date'")
        if (issuedList.size == 0)
            ll_hr_issuedBookList.setLayoutParams(
                LinearLayout.LayoutParams(rv_hr_issuedBookList.layoutParams.width, 0))
        else{
            setIssuedHRAdapter()
        }

        historyReader = mDBHelper.listHR(user, " hrRelevance = 0")
        if (historyReader.size == 0){
            tv_hr_listNull.visibility = TextView.VISIBLE
            ll_hrBookList.setLayoutParams(
                LinearLayout.LayoutParams(rv_hr_returnedBookList.layoutParams.width, 0))
        }else{
            var itemHRAdapter =  ItemHRAdapter(historyReader)
            setRV(rv_hr_returnedBookList, itemHRAdapter)
            itemHRAdapter.onItemClick = { item ->
                val intent = Intent(this, EditionActivity::class.java)
                intent.putExtra("id", item.edition.idEdition)
                startActivity(intent)
            }
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun setIssuedHRAdapter() {

        var itemIssuedHRAdapter =  ItemIssuedHRAdapter(issuedList)
        setRV(rv_hr_issuedBookList, itemIssuedHRAdapter)
        itemIssuedHRAdapter.onItemClick = { item ->
            val intent = Intent(this, EditionActivity::class.java)
            intent.putExtra("id", item.edition.idEdition)
            startActivity(intent)
        }
        itemIssuedHRAdapter.onItemClickSelected = { item, flag ->
            if (flag){
                if (!selectIssuedList.contains(item))
                    selectIssuedList.add(item)
            }else{
                if (selectIssuedList.contains(item))
                    selectIssuedList.remove(item)
            }
            if (selectIssuedList.size > 0)
                tv_hr_selectAllIB.visibility = TextView.VISIBLE
            else
                tv_hr_selectAllIB.visibility = TextView.INVISIBLE
        }
        itemIssuedHRAdapter.onItemClickProlong= { item ->
            prolongBook(arrayListOf(item))
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun setDelayedHRAddapter() {
        var itemDelayedHRAdapter =  ItemDelayedHRAdapter(delayedList)
        setRV(rv_hr_delayedBookList, itemDelayedHRAdapter)
        itemDelayedHRAdapter.onItemClick = { item ->
            val intent = Intent(this, EditionActivity::class.java)
            intent.putExtra("id", item.edition.idEdition)
            startActivity(intent)
        }
        itemDelayedHRAdapter.onItemClickSelected = { item, flag ->
            if (flag){
                if (!selectDelayedList.contains(item))
                    selectDelayedList.add(item)
            }else{
                if (selectDelayedList.contains(item))
                    selectDelayedList.remove(item)
            }
            if (selectDelayedList.size > 0)
                tv_hr_selectAllDB.visibility = TextView.VISIBLE
            else
                tv_hr_selectAllDB.visibility = TextView.INVISIBLE
        }
        itemDelayedHRAdapter.onItemClickProlong= { item ->
            prolongBook(arrayListOf(item))
        }
    }

    private fun setRV(rv:RecyclerView, adapter:Any) {
        rv.setHasFixedSize(true)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter as RecyclerView.Adapter<*>
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun initComponents() {
        tv_hr_listNull = findViewById(R.id.tv_hr_listNull)
        ll_hr_delayedBookList = findViewById(R.id.ll_hr_delayedBookList)
        rv_hr_delayedBookList = findViewById(R.id.rv_hr_delayedBookList)
        ll_hr_issuedBookList = findViewById(R.id.ll_hr_issuedBookList)
        rv_hr_issuedBookList = findViewById(R.id.rv_hr_issuedBookList)
        ll_hrBookList = findViewById(R.id.ll_hrBookList)
        rv_hr_returnedBookList = findViewById(R.id.rv_hr_returnedBookList)
        tv_hr_selectAllIB = findViewById(R.id.tv_hr_selectAllIB)
        tv_hr_selectAllIB.setOnClickListener(){
            prolongBook(selectIssuedList)
        }
        tv_hr_selectAllDB = findViewById(R.id.tv_hr_selectAllDB)
        tv_hr_selectAllDB.setOnClickListener(){
            prolongBook(selectDelayedList)
        }
    }

    @RequiresApi(Build.VERSION_CODES.O)
    private fun prolongBook(selectList: ArrayList<HistoryReader>) {
        var num:Long = 0;
        selectList.forEach{
            num += mDBHelper.updateDateReturnHR(it)
        }
        if (num>0){
            val intent = intent
            finish()
            startActivity(intent)
        }else
            Toast.makeText(this, "Не удалось продлить книги.", Toast.LENGTH_SHORT).show()
    }
}