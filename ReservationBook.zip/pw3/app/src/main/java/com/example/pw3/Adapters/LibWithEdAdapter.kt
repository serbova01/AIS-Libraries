package com.example.pw3.Adapters

import android.content.res.Resources
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.RadioButton
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.R
import com.example.pw3.models.Basket
import com.example.pw3.models.NumInLib

class LibWithEdAdapter(private val list:ArrayList<NumInLib>)  :
    RecyclerView.Adapter<LibWithEdAdapter.LibWithEdViewHolder>(){
    var onItemClick: ((NumInLib, CheckBox) -> Unit)? = null

    inner class LibWithEdViewHolder(itemView: View):RecyclerView.ViewHolder(itemView){
        val checkBox:CheckBox = itemView.findViewById(R.id.cb_numInLib)
        val textView_name : TextView = itemView.findViewById(R.id.tv_numInLib_name)
        val textView_address : TextView = itemView.findViewById(R.id.tv_numInLib_address)
        val textView_num : TextView = itemView.findViewById(R.id.tv_numInLib_num)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): LibWithEdViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.lib_with_edition_layout, parent, false)
        return LibWithEdViewHolder(view)
    }

    override fun onBindViewHolder(holder: LibWithEdViewHolder, position: Int) {
        var item = list[position]
        holder.textView_name.text = item.library.nameL
        holder.textView_address.text = item.library.address
        holder.textView_num.text = item.num.toString()
        if (item.reg){
            holder.textView_name.setTypeface(null, Typeface.BOLD)
            holder.textView_address.setTypeface(null, Typeface.BOLD)
            holder.textView_num.setTypeface(null, Typeface.BOLD)
            holder.checkBox.visibility = CheckBox.VISIBLE
        }
        holder.checkBox.setOnClickListener(){
            onItemClick?.invoke(item, holder.checkBox)
        }

    }

    override fun getItemCount(): Int {
        return list.size
    }


}