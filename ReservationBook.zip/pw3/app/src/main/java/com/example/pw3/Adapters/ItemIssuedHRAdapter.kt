package com.example.pw3.Adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.R
import com.example.pw3.models.HistoryReader

class ItemIssuedHRAdapter(val issuedList : ArrayList<HistoryReader>) :
    RecyclerView.Adapter<ItemIssuedHRAdapter.ItemIssuedHRHolder>() {

    var onItemClickProlong: ((HistoryReader) -> Unit)? = null
    var onItemClick: ((HistoryReader) -> Unit)? = null
    var onItemClickSelected: ((HistoryReader, Boolean) -> Unit)? = null

    inner class ItemIssuedHRHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val checkBox: CheckBox = itemView.findViewById(R.id.cb_hrItem)
        val imageView : ImageView = itemView.findViewById(R.id.iv_hrItem_imageEd)
        val tv_title : TextView = itemView.findViewById(R.id.tv_hrItem_titleBook)
        val tv_discription: TextView = itemView.findViewById(R.id.tv_hrItem_discriptionBook)
        val tv_dateIssue : TextView = itemView.findViewById(R.id.tv_hrItem_dateIssue)
        val tv_dateReturn : TextView = itemView.findViewById(R.id.tv_hrItem_dateReturn)
        val tv_libName : TextView = itemView.findViewById(R.id.tv_hrItem_libName)
        val tv_libAddress : TextView = itemView.findViewById(R.id.tv_hrItem_libAddress)
        val tv_invNumber : TextView = itemView.findViewById(R.id.tv_hrItem_invNumber)
        val button: AppCompatButton = itemView.findViewById(R.id.btn_hrItem_prolong)
        init {
            itemView.setOnClickListener(){
                onItemClick?.invoke(issuedList[adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemIssuedHRHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.item_issue_hr_layout, parent, false)
        return ItemIssuedHRHolder(view)
    }

    override fun onBindViewHolder(holder: ItemIssuedHRHolder, position: Int) {
        val item = issuedList[position]
        item.edition.image?.let { holder.imageView.setImageResource(it) }
        holder.tv_title.text = item.edition.nameBook
        holder.tv_discription.text = item.edition.getShortText()
        holder.tv_dateIssue.text = addText(holder.tv_dateIssue, item.dateIssue)
        holder.tv_dateReturn.text = addText(holder.tv_dateReturn, item.dateReturn)
        holder.tv_libName.text = item.library.nameL
        holder.tv_libAddress.text = item.library.address
        holder.tv_invNumber.text = addText(holder.tv_invNumber, item.invNum.toString())
        holder.button.setOnClickListener(){
            onItemClickProlong?.invoke(item)
        }
        holder.checkBox.setOnClickListener(){
            onItemClickSelected?.invoke(item, holder.checkBox.isChecked)
        }
    }

    override fun getItemCount(): Int {
        return issuedList.size
    }

    fun addText(textView: TextView, text:String):String{
        return textView.text.toString() + ": " + text
    }
}