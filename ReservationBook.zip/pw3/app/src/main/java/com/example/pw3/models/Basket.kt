package com.example.pw3.models

import android.content.res.Resources
import com.example.pw3.R

class Basket(catalog: Catalog, isFavorite:Boolean, library: Library) {
    var id:Int = 0
    var catalog = catalog
    var num:Int = 0
    var isSelect:Boolean = false
    var isFavorite:Boolean = isFavorite
    var library = library
    constructor(id:Int, catalog: Catalog, num:Int, isSelect:Boolean, isFavorite:Boolean, library: Library) : this(catalog, isFavorite, library){
        this.id= id
        this.catalog = catalog
        this.num = num
        this.isSelect = isSelect
        this.isFavorite= isFavorite
        this.library = library
    }
    var id_imgFavorite:Int = setId_ImgFavorite()

    private fun setId_ImgFavorite():Int{
        var id:Int = 0
        if(isFavorite){
            id = R.drawable.ic_favorite_on
        }else
            id = R.drawable.ic_favorite_off

        return id
    }

}