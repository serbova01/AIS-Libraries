package com.example.pw3

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.Adapters.ItemLibForProfileAdapter
import com.example.pw3.profile.EditSubscriberActivity
import com.example.pw3.profile.EditUserActivity
import com.example.pw3.models.SubsNum
import com.example.pw3.models.User


class ProfileActivity : AppCompatActivity() {

    private lateinit var et_firstname:TextView
    private lateinit var et_secondname:TextView
    private lateinit var et_lastname:TextView
    private lateinit var et_phonenumber:TextView
    private lateinit var et_email:TextView
    private lateinit var et_address:TextView
    private lateinit var et_login:TextView
    private lateinit var rv_profile_libs:RecyclerView
    lateinit var tv_profile_loginUser:TextView
    lateinit var tv_saveDefaultLib:TextView

    var mSettings: SharedPreferences? = null
    var is_logged:Boolean = false
    private lateinit var mDBHelper: Server
    private var user: User? = null
    var idDefaultLib: Int = 0
    lateinit var listSubsNum:ArrayList<SubsNum>
    lateinit var itemLibForProfileAdapter:ItemLibForProfileAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profile)

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
        }
        this.title = getString(R.string.dataUserSystem)

        //connect()
        init()
    }

    private fun initComponents() {
        rv_profile_libs = findViewById(R.id.rv_profile_libs)

        et_firstname = findViewById(R.id.et_profile_firstname)
        et_firstname.text = user?.subscriber?.firstName ?: ""
        et_secondname = findViewById(R.id.et_profile_secondname)
        et_secondname.text = user?.subscriber?.secondName ?: ""
        et_lastname = findViewById(R.id.et_profile_lastname)
        et_lastname.text = user?.subscriber?.lastName ?: ""
        et_phonenumber = findViewById(R.id.et_profile_phonenumber)
        et_phonenumber.text = user?.subscriber?.phoneNumber ?: ""
        et_address = findViewById(R.id.et_profile_address)
        et_address.text = user?.subscriber?.address
        et_email = findViewById(R.id.et_profile_email)
        et_email.text = user?.subscriber?.emailS ?: ""
        et_login = findViewById(R.id.et_profile_login)
        et_login.text = user?.login ?: ""
        //et_phonenumber.isEnabled = false
        //et_email.isEnabled = false
        tv_profile_loginUser = findViewById(R.id.tv_profile_loginUser)
        tv_saveDefaultLib = findViewById(R.id.tv_saveDefaultLib)
        tv_saveDefaultLib.setOnClickListener(){
            onUpdateLibUser()
        }
    }

    private fun onUpdateLibUser() {
        if (idDefaultLib != 0){
            var num:Long = mDBHelper.updateLibUser(idDefaultLib, user)
            if(num <=0)
                Toast.makeText(this, "Не удалось изменить библиотеку поумолчанию.",
                    Toast.LENGTH_LONG).show()
        }else{
            Toast.makeText(this, getString(R.string.defaultLibNull), Toast.LENGTH_LONG).show()
        }
    }

    fun init(){
        mDBHelper = Server(this)
        mDBHelper.connect()
        mSettings = this.getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        is_logged = mSettings!!.getBoolean("is_logged", false)
        var email = ""
        if (is_logged){
            email = mSettings!!.getString("email", "").toString()
            user = mDBHelper.findUserByEmail(email)
            initComponents()
            if (user != null){
                val editor = mSettings!!.edit()
                var selectedFragment = mSettings!!.getString("selectedFragment", "").toString()
                editor.putString("selectedFragment", "profile").apply()
                selectedFragment = mSettings!!.getString("selectedFragment", "").toString()
                idDefaultLib = user!!.library.id
                tv_profile_loginUser.text = user?.login ?: ""
                listSubsNum = mDBHelper.listSubsNums(user?.subscriber)
                if (listSubsNum.count() > 0){
                    idDefaultLib = user!!.library.id
                    listSubsNum.forEach{it.isSelect = it.library.id == idDefaultLib}
                    setRV()
                }
            }else{
                Toast.makeText(this, getString(R.string.profile_userNull), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setRV() {
        rv_profile_libs.setHasFixedSize(true)
        rv_profile_libs.layoutManager = LinearLayoutManager(this)
        itemLibForProfileAdapter = ItemLibForProfileAdapter(listSubsNum)
        itemLibForProfileAdapter.onItemClick = { item ->
            onOpenDetailsLibs(item.library.id)
        }
        itemLibForProfileAdapter.onItemCheck = { item, checkBox ->
            onChecked(checkBox,item)
        }
        rv_profile_libs.adapter = itemLibForProfileAdapter
        
    }

    private fun onChecked(checkBox: CheckBox, item:SubsNum) {
        if (checkBox.isChecked){
            itemLibForProfileAdapter.setActiveQuery(item)
            idDefaultLib = item.library.id
        }else{
            if (idDefaultLib == item.library.id){
                idDefaultLib = 0
            }
        }
        if (idDefaultLib != user!!.library.id)
            tv_saveDefaultLib.visibility = TextView.VISIBLE
        else
            tv_saveDefaultLib.visibility = TextView.INVISIBLE
    }

    fun onOpenDetailsLibs(idLib: Int){
        val intent = Intent(this@ProfileActivity, DetailsLibraryActivity::class.java)
        intent.putExtra("idLib", idLib)
        startActivity(intent)
    }

    fun onOpenEditProfile(view: View){
        val intent = Intent(this@ProfileActivity, EditUserActivity::class.java)
        startActivity(intent)
    }

    fun onOpenEditDataSubs(view: View){
        val intent = Intent(this@ProfileActivity, EditSubscriberActivity::class.java)
        startActivity(intent)
    }
}