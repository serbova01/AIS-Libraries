package com.example.pw3.models

import android.media.Image
import com.example.pw3.R
import java.util.*
import kotlin.collections.ArrayList

class Catalog (idEdition:Int, publHouse : String, year : Int, discription : String?, numPages : Int,
               price : Double, nameBook : String, nameCycle : String?, ISBN:String){
    var image: Int = 0
    val idEdition = idEdition               //4
    val publHouse = publHouse               //10
    val year = year                         //12
    val discription: String? = discription  //6
    val numPages = numPages                 //9
    val ISBN = ISBN                         //5
    val price = price                       //7
    val nameBook = nameBook                 //1
    val nameCycle:String?= nameCycle        //14
    var nameAuthors:ArrayList<Author> = ArrayList()

    public fun getShortText(): String {

        var str = "${publHouse.trim()}"

        if (nameCycle?.isNotEmpty() == true)
            str += "\n$nameCycle"
        var authorStr:String = getAuthorStr()
        return "$str\n$authorStr"

    }

    fun getAuthorStr(): String {
        var namesAuthors : String = ""
        nameAuthors.forEach{
            namesAuthors += it.shorName
            namesAuthors += ", "
        }
        namesAuthors = namesAuthors.removeRange(namesAuthors.length-3, namesAuthors.length-1)
        return namesAuthors
    }

    /*public override fun toString() : String{

        var namesAuthors : String = " "
        nameAuthors.forEach{
            namesAuthors += it.shorName
            namesAuthors += ", "
        }
        var str = "Издательство " + publHouse +
                "\nГод издаия " + year +
                "\nЦена " + price +
                "\nЧисло страниц " + numPages
        namesAuthors.removeRange(namesAuthors.length-2, namesAuthors.length)

        if (nameCycle?.isNotEmpty() == true)
            str += "\nЦикл $nameCycle"
        if (discription?.isNotEmpty() == true)
            str+= "\nОписание $discription"

        return "$str\nАвтор(-ы) $namesAuthors"
    }*/

    public fun addAuthorToNameAuthors(nameAuthor: Author){
        if (nameAuthors.isEmpty())
            nameAuthors = ArrayList()
        nameAuthors.add(nameAuthor)
    }
}