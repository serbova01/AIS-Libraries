package com.example.pw3.Adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.R
import com.example.pw3.models.Request
import com.example.pw3.models.Reservation

class ItemRequestListAdapter (var list:ArrayList<Request>) :
    RecyclerView.Adapter<ItemRequestListAdapter.ItemRequestListHolder>(){

    var onItemClick: ((Request) -> Unit)? = null

    inner class ItemRequestListHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val imageView : ImageView = itemView.findViewById(R.id.iv_requestItem_imageEd)
        val tv_title : TextView = itemView.findViewById(R.id.tv_requestItem_titleBook)
        val tv_libName : TextView = itemView.findViewById(R.id.tv_requestItem_libName)
        val tv_libAddress : TextView = itemView.findViewById(R.id.tv_requestItem_libAddress)
        val tv_discription : TextView = itemView.findViewById(R.id.tv_requestItem_discriptionBook)
        val tv_status: TextView = itemView.findViewById(R.id.tv_requestItem_rStatus)
        init {
            itemView.setOnClickListener {
                onItemClick?.invoke(list[adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemRequestListHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.item_request_list_layout, parent, false)
        return ItemRequestListHolder(view)
    }

    override fun onBindViewHolder(holder: ItemRequestListHolder, position: Int) {
        val item = list[position]
        item.catalog.image?.let { holder.imageView.setImageResource(it) }
        holder.tv_title.text = item.catalog.nameBook
        holder.tv_discription.text = item.catalog.getShortText()
        holder.tv_libName.text = item.library.nameL
        holder.tv_libAddress.text = item.library.address
        holder.tv_status.text = item.status
    }

    override fun getItemCount(): Int {
        return  list.size
    }
}