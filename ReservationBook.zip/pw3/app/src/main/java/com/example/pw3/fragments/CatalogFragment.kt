package com.example.pw3.fragments

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.Adapters.ItemCatalogAdapter
import com.example.pw3.EditionActivity
import com.example.pw3.ProfileActivity
import com.example.pw3.R
import com.example.pw3.Server
import com.example.pw3.models.Catalog
import com.example.pw3.models.User
import com.example.pw3.registration.RegistrationActivity
import java.io.IOException
import java.sql.SQLException


class CatalogFragment : Fragment() {

    private lateinit var rv_catalog:RecyclerView
    lateinit var sv_catalog:SearchView

    lateinit var mSettings: SharedPreferences
    private lateinit var mDBHelper: Server
    private lateinit var itemCatalogAdapter: ItemCatalogAdapter
    private var user: User? = null
    lateinit var catalog:ArrayList<Catalog>


    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        rv_catalog = view.findViewById(R.id.rv_catalog)
        sv_catalog = view.findViewById(R.id.sv_catalog)

        init(view)
    }
    private fun init(view: View) {
        //connect(view)
        mDBHelper = Server(this.context)
        mDBHelper.connect()
        mSettings = view.context.getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        val is_logged = mSettings!!.getBoolean("is_logged", true)
        var email:String = ""
        if (is_logged){
            email = mSettings!!.getString("email", "").toString()
        }
        user = mDBHelper.findUserByEmail(email)
        catalog = mDBHelper?.listCatalog() as ArrayList<Catalog>
        initComponents()

    }

    private fun initComponents() {
        rv_catalog.setHasFixedSize(true)
        rv_catalog.layoutManager = LinearLayoutManager(requireView().context)
        itemCatalogAdapter = ItemCatalogAdapter(catalog)
        itemCatalogAdapter.onItemClick = { item ->
            val intent = Intent(context, EditionActivity::class.java)
            intent.putExtra("id", item.idEdition)
            startActivity(intent)
        }
        rv_catalog.adapter = itemCatalogAdapter

        sv_catalog.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                return false
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                if (newText != null) {
                    filter(newText)
                }
                return false
            }
        })
    }

    private fun filter(text: String) {
        val filteredlist: ArrayList<Catalog> = ArrayList()
        for (item in catalog) {
            if (item.nameBook.toLowerCase().contains(text.toLowerCase()) ||
                item.nameCycle?.toLowerCase()?.contains(text.toLowerCase()) ?: false ||
                item.publHouse.toLowerCase().contains(text.toLowerCase()) ||
                item.nameAuthors.any{it.firstname.toLowerCase().contains(text.toLowerCase())}){

                filteredlist.add(item)
            }
        }
        if (filteredlist.isEmpty()) {
            Toast.makeText(context, getString(R.string.filtredDataNotFound), Toast.LENGTH_SHORT).show()
        } else {
            itemCatalogAdapter.filterList(filteredlist)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        requireActivity().title = getString(R.string.catalog)
        return inflater.inflate(R.layout.fragment_catalog, container, false)
    }

    companion object {
        @JvmStatic
        fun newInstance() = CatalogFragment()
    }
}