package com.example.pw3.profile

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.Adapters.ItemFavoritesAdapter
import com.example.pw3.EditionActivity
import com.example.pw3.R
import com.example.pw3.Server
import com.example.pw3.models.Basket
import com.example.pw3.models.Catalog
import com.example.pw3.models.User

class FavoritesListActivity : AppCompatActivity() {

    private lateinit var mDBHelper: Server
    private var user: User? = null
    lateinit var mSettings: SharedPreferences
    private lateinit var itemFavoritesAdapter: ItemFavoritesAdapter
    lateinit var favorites: ArrayList<Catalog>

    lateinit var rv_favorites:RecyclerView
    lateinit var tv_favorites_listNull:TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_favorites_list)

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
        }
        this.title = getString(R.string.favorites)

        rv_favorites = findViewById(R.id.rv_favorites)
        tv_favorites_listNull = findViewById(R.id.tv_favorites_listNull)

        init()
    }

    fun init(){
        mDBHelper = Server(this)
        mDBHelper.connect()
        mSettings = this.getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences

        var is_logged = mSettings!!.getBoolean("is_logged", false)
        if (is_logged){
            var email = mSettings!!.getString("email", "").toString()
            user = mDBHelper.findUserByEmail(email)
            mSettings.edit().putString("selectedFragment", "profile").apply()
            favorites = mDBHelper.listFavorites(user)
            if (favorites.size == 0)
                tv_favorites_listNull.visibility = TextView.VISIBLE
            setRV()
        }
    }

    private fun setRV() {
        rv_favorites.setHasFixedSize(true)
        rv_favorites.layoutManager = LinearLayoutManager(this)
        itemFavoritesAdapter = ItemFavoritesAdapter(favorites)
        itemFavoritesAdapter.onItemClick = { item ->
            val intent = Intent(this, EditionActivity::class.java)
            intent.putExtra("id", item.idEdition)
            startActivity(intent)
        }
        itemFavoritesAdapter.onItemClickBasket = { item ->
            var basket = Basket(item, true, user!!.library)
            var num:Long = mDBHelper.insertBasket(basket, user!!, null)
            if (num<=0)
                Toast.makeText(this, "Не удалось добавить в корзину.", Toast.LENGTH_SHORT).show()
        }
        itemFavoritesAdapter.onItemClickDelete = { it ->
            var num:Long = mDBHelper.updateFavoriteBasket(it, user)
            if (num > 0){
                val intent = intent
                finish()
                startActivity(intent)
            }else
                Toast.makeText(this, "Не удалось удалить из избранного.", Toast.LENGTH_SHORT).show()
        }

        rv_favorites.adapter = itemFavoritesAdapter
    }
}