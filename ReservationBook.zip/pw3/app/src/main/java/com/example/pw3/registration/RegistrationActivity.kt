package com.example.pw3.registration

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.database.sqlite.SQLiteDatabase
import android.os.Bundle
import android.text.InputFilter
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.view.MenuItem
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.AppCompatButton
import com.example.pw3.MainActivity
import com.example.pw3.R
import com.example.pw3.Server
import com.example.pw3.models.Subscriber
import com.example.pw3.models.User
import java.io.IOException
import java.sql.SQLException


class RegistrationActivity : AppCompatActivity() {

    lateinit var et_login_reg: EditText
    lateinit var et_pass_reg: EditText
    lateinit var et_confim_pass_reg: EditText
    lateinit var et_email: EditText
    lateinit var b_sign_in: Button
    lateinit var et_reg_phoneNumber:EditText
    lateinit var tv_reg_errorPhNum:TextView

    lateinit var mSettings: SharedPreferences
    private lateinit var mDBHelper: Server
    var maskPhNum = "+0 (000) 000-00-00"
    var user:User? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_registration)

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
        }

        this.title = getString(R.string.registration)
        /*mSettings = getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        val is_logged = mSettings!!.getBoolean("is_logged", false)
        if (is_logged){
            email = mSettings!!.getString("email", "").toString()
        }*/
        init()
    }

    fun init(){
        //connect()
        mDBHelper = Server(this)
        mDBHelper.connect()
        mSettings = this.getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences

        et_login_reg = findViewById<EditText>(R.id.et_reg_login)
        et_pass_reg = findViewById<EditText>(R.id.et_reg_pass)
        et_confim_pass_reg = findViewById<EditText>(R.id.et_reg_confim_pass)
        et_email = findViewById<EditText>(R.id.et_reg_email)
        et_reg_phoneNumber = findViewById<EditText>(R.id.et_reg_phoneNumber)
        tv_reg_errorPhNum = findViewById<EditText>(R.id.tv_reg_errorPhNum)
        val filterPhNumber = InputFilter { source, start, end, dest, dstart, dend ->
            for (i in start until end) {
                var j = et_reg_phoneNumber.text.toString().length

                if (!((Character.isDigit(source[i]) &&
                            Character.isDigit(maskPhNum[j])) ||
                            source[i].toString().equals(maskPhNum[j].toString()) ||
                            (j == 1 && source[i].equals("7")))) {
                    tv_reg_errorPhNum.visibility = TextView.VISIBLE
                    return@InputFilter ""
                }
            }
            null
        }
        et_reg_phoneNumber.filters = arrayOf(filterPhNumber)

        b_sign_in = findViewById<Button>(R.id.btn_reg_go)
        b_sign_in.setOnClickListener{
            registration()
        }
        val filterLogin =
            InputFilter { source, start, end, dest, dstart, dend ->
                for (i in start until end) {
                    if (!Character.isLetterOrDigit(source[i])) {
                        return@InputFilter ""
                    }
                }
                null
            }
        et_login_reg.filters = arrayOf(filterLogin)

        val filterPass =
            InputFilter { source, start, end, dest, dstart, dend ->
                for (i in start until end) {
                    if (Character.isWhitespace(source[i])) {
                        return@InputFilter ""
                    }
                }
                null
            }
        et_pass_reg.filters = arrayOf(filterPass)
        et_confim_pass_reg.filters = arrayOf(filterPass)
    }

    private fun registration() {
        if (checkNull()){
            user = User(et_login_reg.text.toString(), et_pass_reg.text.toString(), et_email.text.toString())

            if(checkUser(user!!)){
                val editor = mSettings.edit()
                editor.putBoolean("is_logged", false).apply()
                editor.putString("email", "").apply()
                var phoneNumber = et_reg_phoneNumber.text.toString()

                var subscriber = mDBHelper.findSubscriberByPhNumber(phoneNumber)
                user!!.subscriber = subscriber
                if (subscriber != null && subscriber.emailS == null){
                    //если этот номер зарегистрирован в системе, но абонент не зарегистрирован в приложении
                    var numInsertRow: Long = mDBHelper.insertUser(user!!)
                    if (numInsertRow>0){
                        goToMainActivity()
                    }else Toast.makeText(this, "Не удалось добавить зарегистрированного абонента", Toast.LENGTH_SHORT).show()
                }else{
                    if (subscriber == null){
                        val intent =
                            Intent(this@RegistrationActivity, FindLibraryActivity::class.java)

                        //intent.putExtra("newUser", user)
                        val newUser = Bundle()
                        newUser.putString("login", user!!.login)
                        newUser.putString("email", user!!.email)
                        newUser.putString("password", user!!.password)
                        newUser.putString("role", user!!.role)
                        newUser.putString("phNumber", phoneNumber)
                        intent.putExtras(newUser)
                        startActivity(intent)
                    }else{
                        if (subscriber.emailS != user!!.email){
                            createAlert(subscriber)
                        }
                    }
                }

                /*val intent = Intent(this, PhNumVerificationActivity::class.java)
                val newUser = Bundle()
                newUser.putString("login", user.login)
                newUser.putString("email", user.email)
                newUser.putString("password", user.password)
                newUser.putString("role", user.role)
                intent.putExtras(newUser);
                startActivity(intent)*/

            }
        }
    }

    private fun goToMainActivity() {
        mSettings = getSharedPreferences("my_storage", Context.MODE_PRIVATE)
        val editor = mSettings.edit()
        editor.putBoolean("is_logged", true).apply()
        editor.putString("email", user!!.email).apply()
        val intent = Intent(this@RegistrationActivity, MainActivity::class.java)
        startActivity(intent)
    }

    private fun createAlert(subscriber: Subscriber) {
        val alertDialog = AlertDialog.Builder(this@RegistrationActivity)
        alertDialog.setTitle(R.string.alertTitle_phNumIsSystemWithOtherEmail)
        var text = "Такой номер телефона зарегистрирован в системе с другим email-ом: " + subscriber.emailS +
                " .\n Хотите восстановить профиль или изменить данные профиля?"

        alertDialog.setMessage(text)
        alertDialog.setIcon(R.mipmap.ic_launcher)
        alertDialog.setPositiveButton("Восстановить профиль"){dialog, id->
            restoreProfile(subscriber)
        }
        alertDialog.setNegativeButton("Изменить данные"){dialog, id->
            var numInsertRow: Long = mDBHelper.insertUser(user!!)
            if(numInsertRow <=0) Toast.makeText(this, "Не удалось добавить зарегистрированного абонента", Toast.LENGTH_SHORT).show()
            else{
                goToMainActivity()
            }
        }

        alertDialog.show()
    }

    private fun restoreProfile(subscriber: Subscriber) {
        user = mDBHelper.findUserByEmail(user!!.subscriber?.emailS ?: "")
        goToMainActivity()
    }

    private fun checkUser( user: User): Boolean {
        if (!et_pass_reg.text.toString().equals(et_confim_pass_reg.text.toString())){
            Toast.makeText(this, getString(R.string.pssNoMatch), Toast.LENGTH_SHORT).show()
            return false
        }
        else{
            var findUser = mDBHelper.findUserByEmail(user.email)
            if (findUser != null){
                Toast.makeText(this, getString(R.string.emailReg), Toast.LENGTH_SHORT).show()
                return false
            }
            findUser = mDBHelper.findUserByLogin(user.login)
            if (findUser != null){
                Toast.makeText(this, getString(R.string.loginReg), Toast.LENGTH_SHORT).show()
                return false
            }
        }
        return true
    }

    private fun checkNull(): Boolean {
        if (et_login_reg.text.isEmpty() or et_pass_reg.text.isEmpty() or et_confim_pass_reg.text.isEmpty() or et_email.text.isEmpty() or
                et_reg_phoneNumber.text.isEmpty()) {
            if (et_login_reg.text.isEmpty() and et_pass_reg.text.isEmpty() and et_confim_pass_reg.text.isEmpty() and et_email.text.isEmpty() and
                et_reg_phoneNumber.text.isEmpty()) {

                Toast.makeText(this, getString(R.string.l_p_clean), Toast.LENGTH_SHORT).show()
                et_login_reg.setBackgroundResource(R.drawable.round_edge)
                et_pass_reg.setBackgroundResource(R.drawable.round_edge)
                et_confim_pass_reg.setBackgroundResource(R.drawable.round_edge)
                et_email.setBackgroundResource(R.drawable.round_edge)
                et_reg_phoneNumber.setBackgroundResource(R.drawable.round_edge)
                return false
            }else{
                if (et_login_reg.text.isEmpty()) {
                    Toast.makeText(this, getString(R.string.loginNull), Toast.LENGTH_SHORT).show()
                    et_login_reg.setBackgroundResource(R.drawable.round_edge)
                    return false
                }else{
                    if (et_email.text.isEmpty()) {
                        Toast.makeText(this, getString(R.string.emailNull), Toast.LENGTH_SHORT).show()
                        et_email.setBackgroundResource(R.drawable.round_edge)
                        return false
                    }else{
                        if (et_pass_reg.text.isEmpty()) {
                            Toast.makeText(this, getString(R.string.passNull), Toast.LENGTH_SHORT).show()
                            et_pass_reg.setBackgroundResource(R.drawable.round_edge)
                            return false
                        }else{
                            if (et_confim_pass_reg.text.isEmpty()) {
                                Toast.makeText(this, getString(R.string.confimPassNull), Toast.LENGTH_SHORT).show()
                                et_confim_pass_reg.setBackgroundResource(R.drawable.round_edge)
                                return false
                            }else{
                                if (et_reg_phoneNumber.text.isEmpty()) {
                                    Toast.makeText(this, getString(R.string.confimPassNull), Toast.LENGTH_SHORT).show()
                                    et_reg_phoneNumber.setBackgroundResource(R.drawable.round_edge)
                                    return false
                                }
                            }
                        }
                    }
                }
            }
        }
        return true
    }
}