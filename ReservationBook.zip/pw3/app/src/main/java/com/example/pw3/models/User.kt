package com.example.pw3.models

import java.io.Serializable

class User() : Serializable {
    var id=0
    var login = ""
    var password = ""
    var email = ""
    var role = "Subscriber"
    var subscriber:Subscriber? = null
    var library:Library = Library()

    constructor(login: String?, password: String?, email: String?, role: String?) : this() {
        this.login = login.toString()
        this.password = password.toString()
        this.role = role.toString()
        this.email = email.toString()
    }

    constructor(id:Int, login:String, password:String, email:String, subscriber: Subscriber, library: Library) : this() {
        this.id=id
        this.login = login
        this.password = password
        this.subscriber = subscriber
        this.email = email
        this.library = library
    }

    constructor(login:String, password:String, email:String) : this() {
        this.login = login
        this.password = password
        this.email = email
    }
}