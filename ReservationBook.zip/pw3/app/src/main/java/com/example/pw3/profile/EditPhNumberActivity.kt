package com.example.pw3.profile

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.telephony.SmsManager
import android.text.TextUtils
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.widget.AppCompatButton
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.example.pw3.R
import com.example.pw3.Server
import com.example.pw3.models.User

class EditPhNumberActivity : AppCompatActivity() {
    lateinit var tv_confimPhNum: TextView
    lateinit var et_codeConfim: EditText
    lateinit var et_phoneNumber: EditText
    lateinit var btn_checkCode: AppCompatButton
    lateinit var btn_sendCode: AppCompatButton

    lateinit var mSettings: SharedPreferences
    private lateinit var mDBHelper: Server
    lateinit var user: User
    private var code = ""
    val permissionRequest = 101
    var phoneNumber:String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_ph_num_verification)

        var actionBar = getSupportActionBar()
        if (actionBar != null) {
            actionBar.setDisplayHomeAsUpEnabled(true)
        }
        mDBHelper = Server(this)
        mDBHelper.connect()
        mSettings = getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        val is_logged = mSettings.getBoolean("is_logged", false)
        if (is_logged){
            var email = mSettings.getString("email", "").toString()
            user = mDBHelper.findUserByEmail(email)
        }

        init()
    }
    fun init(){
        //connect()
        mDBHelper = Server(this)
        mDBHelper.connect()

        tv_confimPhNum = findViewById(R.id.tv_confimPhNum)
        et_codeConfim = findViewById(R.id.et_codeConfim)
        et_phoneNumber = findViewById(R.id.et_phoneNumber)
        btn_checkCode = findViewById(R.id.btn_checkCode)
        //btn_checkCode.isEnabled = false
        btn_checkCode.setOnClickListener {
            checkCode()
        }
        btn_sendCode = findViewById(R.id.btn_sendCode)
        btn_sendCode.setOnClickListener {
            sendCode()
        }
    }

    private fun checkCode() {
        if (checkNull()){
            if (et_codeConfim.text.toString().equals(code)) {
                var subscriber = mDBHelper.findSubscriberByPhNumber(phoneNumber)
                if (subscriber == null){
                    var num = mDBHelper.updatePhNumber(user.subscriber, phoneNumber)
                    if (num > 0){
                        val editor = mSettings.edit()
                        editor.putString("email", user.email).apply()
                        Toast.makeText(this, getString(R.string.phoneNumberEdit), Toast.LENGTH_SHORT).show()
                        val intent = Intent(this@EditPhNumberActivity, EditSubscriberActivity::class.java)
                        startActivity(intent)
                    }else{
                        Toast.makeText(this, "Не удалось изменить номер телефона", Toast.LENGTH_SHORT).show()
                    }
                }else
                    Toast.makeText(this, getString(R.string.phoneNumReg), Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, getString(R.string.falseCode), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun sendMessage() {

        val permissionCheck = ContextCompat.checkSelfPermission(this,
            android.Manifest.permission.SEND_SMS)
        if (permissionCheck == PackageManager.PERMISSION_GRANTED) {
            myMessage()
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(
                android.Manifest.permission.SEND_SMS), permissionRequest)
        }
    }
    private fun myMessage() {
        val myNumber: String = et_phoneNumber.text.toString().trim()
        if (myNumber == "") {
            Toast.makeText(this, "Field cannot be empty", Toast.LENGTH_SHORT).show()
        } else {
            if (TextUtils.isDigitsOnly(myNumber)) {
                val smsManager: SmsManager = SmsManager.getDefault()
                smsManager.sendTextMessage(myNumber, null, code, null, null)
                Toast.makeText(this, getString(R.string.codeSend), Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, getString(R.string.phNumInCorrect), Toast.LENGTH_SHORT).show()
            }
        }
    }
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults:
    IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permissionRequest) {
            if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                myMessage();
            } else {
                Toast.makeText(this, "You don't have required permission to send a message",
                    Toast.LENGTH_SHORT).show();
            }
        }
    }

    private fun sendCode() {
        generateCode()
        code = "111"
        //sendMessage()
        phoneNumber = et_phoneNumber.text.toString()

        btn_checkCode.isEnabled = true

    }
    private fun checkNull(): Boolean {
        if (et_codeConfim.text.isNotEmpty() and et_phoneNumber.text.isNotEmpty()){
            return true
        }else{
            if (et_codeConfim.text.isEmpty())
                Toast.makeText(this, getString(R.string.confimCodeNull), Toast.LENGTH_SHORT).show()
            else{
                if (et_phoneNumber.text.isEmpty())
                    Toast.makeText(this, getString(R.string.phoneNumberNull), Toast.LENGTH_SHORT).show()
            }
        }

        return false
    }

    private fun generateCode() {
        val num = IntRange(0, 9)
        var i:Int = 1
        code = ""
        while (i<5){
            code += num.random().toString()
            i++
        }
    }
}