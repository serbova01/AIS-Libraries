package com.example.pw3;

import android.content.ContentValues;
import android.content.Context;
import android.content.res.Resources;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;
import android.util.Log;

import androidx.annotation.RequiresApi;

import com.example.pw3.models.Author;
import com.example.pw3.models.Basket;
import com.example.pw3.models.Catalog;
import com.example.pw3.models.HistoryReader;
import com.example.pw3.models.Library;
import com.example.pw3.models.NumInLib;
import com.example.pw3.models.Request;
import com.example.pw3.models.Reservation;
import com.example.pw3.models.ReservationPrewie;
import com.example.pw3.models.SubsNum;
import com.example.pw3.models.Subscriber;
import com.example.pw3.models.User;

import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Server extends SQLiteOpenHelper {

    private static String DB_NAME = "systemLibraries3.db";
    private static String DB_PATH = "";
    private static final int DB_VERSION = 20;
    private SQLiteDatabase mDataBase;
    private final Context mContext;
    private boolean mNeedUpdate = false;

    public void connect() throws Exception {
        try {
            updateDataBase();
        } catch (IOException mIOException) {
            throw new Exception("UnableToUpdateDatabase");
        }
        try {
            mDataBase = getWritableDatabase();
        } catch (SQLException mSQLException) {
            throw mSQLException;
        }
    }

    public Server(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
        if (android.os.Build.VERSION.SDK_INT >= 17)
            DB_PATH = context.getApplicationInfo().dataDir + "/databases/";
        else
            DB_PATH = "/data/data/" + context.getPackageName() + "/databases/";
        this.mContext = context;
        copyDataBase();
        this.getReadableDatabase();
    }

    public void updateDataBase() throws IOException {
        if (mNeedUpdate) {
            File dbFile = new File(DB_PATH + DB_NAME);
            if (dbFile.exists())
                dbFile.delete();
            copyDataBase();
            mNeedUpdate = false;
        }
    }
    private boolean checkDataBase() {
        File dbFile = new File(DB_PATH + DB_NAME);
        return dbFile.exists();
    }

    private void copyDataBase() {
        if (!checkDataBase()) {
            this.getReadableDatabase();
            this.close();
            try {
                copyDBFile();
            } catch (IOException mIOException) {
                throw new Error("ErrorCopyingDataBase");
            }
        }
    }
    private void copyDBFile() throws IOException {
        InputStream mInput = mContext.getAssets().open(DB_NAME);
        OutputStream mOutput = new FileOutputStream(DB_PATH +
                DB_NAME);
        byte[] mBuffer = new byte[1024];
        int mLength;
        while ((mLength = mInput.read(mBuffer)) > 0)
            mOutput.write(mBuffer, 0, mLength);
        mOutput.flush();
        mOutput.close();
        mInput.close();
    }
    public boolean openDataBase() throws SQLException {
        mDataBase = SQLiteDatabase.openDatabase(DB_PATH + DB_NAME,
                null, SQLiteDatabase.CREATE_IF_NECESSARY);
        return mDataBase != null;
    }

    @Override
    public synchronized void close() {
        if (mDataBase != null)
            mDataBase.close();
        super.close();
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        if (newVersion > oldVersion)
            mNeedUpdate = true;
    }

    public User checkAuthorizeUser(String login, String pass){

        Cursor cursor = mDataBase.rawQuery("SELECT * FROM Subscriber " +
                "join userSystem on sEmail = uEmail left join Library on lId = uLibId " +
                "where uLogin = '"+ login + "' and uPass = '" + pass + "' and uRole = 'Subscriber'", null);

        //Cursor cursor = mDataBase.rawQuery("SELECT * FROM Subscriber", null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            User user = setUserSubs(cursor);

            cursor.moveToNext();
            cursor.close();

            return user;
        }
        return null;
    }

    public ArrayList<Catalog> listCatalog(){
        ArrayList<Catalog> list = new ArrayList<Catalog>();
        //
        Cursor cursor = mDataBase.rawQuery("SELECT * FROM Book " +
                "join edition on bId = eBookId " +
                "left join cycle on bCycleId = cId " +
                "join bookauthor on baBookId = bId "+
                "join author on aId = baAuthorId", null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Author author = new Author(cursor.getString(19),cursor.getString(20),cursor.getString(21));
            boolean find = false;

            for (Catalog query:list) {
                if (query.getIdEdition() == Integer.valueOf(cursor.getString(4))){
                    query.addAuthorToNameAuthors(author);
                    find = true;
                    break;
                }
            }
            if (!find){
                ArrayList<Author> list1 = new ArrayList<Author>();
                list1.add(author);
                int num = cursor.getColumnCount();
                Catalog catalog = new Catalog(cursor.getInt(4), cursor.getString(10),
                        cursor.getInt(12), cursor.getString(6), cursor.getInt(9),
                        cursor.getDouble(7), cursor.getString(1), cursor.getString(14), cursor.getString(5));
                catalog.setImage(convertNameFileToIdForDrawble(cursor.getString(8)));
                catalog.addAuthorToNameAuthors(author);

                list.add(catalog);
            }
            cursor.moveToNext();
        }
        cursor.close();

        return list;
    }
    private int convertNameFileToIdForDrawble(String img) {
        Resources resources = mContext.getResources();
        int resourceId=0;
        if (!img.isEmpty()){
            String str = img.split("\\.")[0];
            resourceId = resources.getIdentifier(str, "drawable", mContext.getPackageName());
        }
        return resourceId;
    }

    public User findUserByEmail(String email) {
        Cursor cursor = mDataBase.rawQuery("SELECT * FROM Subscriber " +
                "join userSystem on sEmail = uEmail left join Library on lId = uLibId " +
                "where uEmail = '" + email + "'", null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            User user = setUserSubs(cursor);
            cursor.moveToNext();
            cursor.close();

            return user;

        }
        return null;
    }

    private User setUserSubs(Cursor cursor) {

        int[] i_cursor = new int[]{cursor.getColumnIndex("sId"), cursor.getColumnIndex("sFirstname"),
                cursor.getColumnIndex("sSecondname"), cursor.getColumnIndex("sLastname"),
                cursor.getColumnIndex("sEmail"), cursor.getColumnIndex("sPhNumber"),
                cursor.getColumnIndex("sAddress"), cursor.getColumnIndex("uLogin"),
                cursor.getColumnIndex("uPass"), cursor.getColumnIndex("uId"), cursor.getColumnIndex("lId"),
                cursor.getColumnIndex("lName"), cursor.getColumnIndex("lCityNumber"),
                cursor.getColumnIndex("lEmail"), cursor.getColumnIndex("lAddress") };

        Cursor cursor1 = mDataBase.rawQuery("SELECT * FROM SubsNumber " +
                "join Library on snLibId = lId join Subscriber on snSubsId = sId " +
                "where sId = " + cursor.getInt(i_cursor[0]), null);
        cursor1.moveToFirst();
        ArrayList<SubsNum> listSubsNum = new ArrayList<>();
        while (!cursor1.isAfterLast()){
            int[] i_cursor1 = new int[]{cursor1.getColumnIndex("snId"), cursor1.getColumnIndex("snSubsNumber"),
                    cursor1.getColumnIndex("lId"), cursor1.getColumnIndex("lName"),
                    cursor1.getColumnIndex("lCityNumber"), cursor1.getColumnIndex("lEmail"),
                    cursor1.getColumnIndex("lAddress")};
            Library l = new Library(cursor1.getInt(i_cursor1[2]), cursor1.getString(i_cursor1[3]),
                    cursor1.getString(i_cursor1[4]), cursor1.getString(i_cursor1[5]), cursor1.getString(i_cursor1[6]));
            listSubsNum.add(new SubsNum(cursor1.getInt(i_cursor1[0]), l, cursor1.getInt(i_cursor1[1])));
            cursor1.moveToNext();
        }
        cursor1.close();

        Library library = new Library(cursor.getInt(i_cursor[10]), cursor.getString(i_cursor[11]),
                cursor.getString(i_cursor[12]), cursor.getString(i_cursor[13]), cursor.getString(i_cursor[14]));
        Subscriber subscriber = new Subscriber(cursor.getInt(i_cursor[0]), cursor.getString(i_cursor[1]),
                cursor.getString(i_cursor[2]), cursor.getString(i_cursor[3]), cursor.getString(i_cursor[4]),
                cursor.getString(i_cursor[5]), cursor.getString(i_cursor[6]));
        subscriber.setListSubsNum(listSubsNum);

        return new User(cursor.getInt(i_cursor[9]), cursor.getString(i_cursor[7]), cursor.getString(i_cursor[8]),
                cursor.getString(i_cursor[4]), subscriber, library);
    }

    public User findUserByLogin(@NotNull String login) {
        Cursor cursor = mDataBase.rawQuery("SELECT * FROM userSystem " +
                " where uLogin = '" + login + "'", null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            cursor = mDataBase.rawQuery("SELECT * FROM userSystem " +
                    "left join subscriber on uEmail = sEmail left join Library on lId = uLibId " +
                    "where uLogin = '" + login + "'", null);
            cursor.moveToFirst();
            User user = null;
            while (!cursor.isAfterLast()){

                int i = cursor.getColumnIndex("uRole");
                if (i>0 && cursor.getString(i).equals("Subscriber")){
                    user = setUserSubs(cursor);
                }
                int[] i_cursor = new int[]{cursor.getColumnIndex("uId"), cursor.getColumnIndex("uLogin"),
                        cursor.getColumnIndex("uPass"), cursor.getColumnIndex("uEmail"), cursor.getColumnIndex("uRole") };
                user = new User(cursor.getString(i_cursor[1]), cursor.getString(i_cursor[2]),
                        cursor.getString(i_cursor[3]), cursor.getString(i_cursor[4]));
                cursor.moveToNext();
                cursor.close();
            }

            return user;

        }
        return null;
    }

    public Subscriber findSubscriberByPhNumber( @NotNull String phoneNumber) {
        Cursor cursor = mDataBase.rawQuery("SELECT * FROM Subscriber " +
                "where sPhNumber = '" + phoneNumber + "'", null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            int[] i_cursor = new int[]{cursor.getColumnIndex("sId"), cursor.getColumnIndex("sFirstname"), cursor.getColumnIndex("sSecondname"),
                    cursor.getColumnIndex("sLastname"), cursor.getColumnIndex("sEmail"), cursor.getColumnIndex("sPhNumber"),
                    cursor.getColumnIndex("sAddress") };

            String address = cursor.getString(i_cursor[5]);
            Subscriber subscriber = new Subscriber(cursor.getInt(i_cursor[0]), cursor.getString(i_cursor[1]), cursor.getString(i_cursor[2]), cursor.getString(i_cursor[3]),
                    cursor.getString(i_cursor[4]), cursor.getString(i_cursor[5]), cursor.getString(i_cursor[6]));
            cursor.moveToNext();
            cursor.close();

            return subscriber;

        }
        return null;
    }

    public long insertUser(@NotNull User user) throws Exception{
        long num = 0;
        try {
            mDataBase.beginTransaction();

            ContentValues newDataForUser = new ContentValues();
            newDataForUser.put("uLogin", user.getLogin());
            newDataForUser.put("uEmail", user.getEmail());
            newDataForUser.put("uPass", user.getPassword());
            newDataForUser.put("uLibId", user.getSubscriber().getListSubsNum().get(0).getLibrary().getId());
            num += mDataBase.insert("userSystem", null, newDataForUser);

            ContentValues emailUpdateSubs = new ContentValues();
            emailUpdateSubs.put("sEmail", user.getEmail());
            String where = "sPhNumber = '" + user.getSubscriber().getPhoneNumber() + "'";
            num += mDataBase.update("subscriber", emailUpdateSubs, where, null);

            mDataBase.setTransactionSuccessful();
            mDataBase.endTransaction();
        }catch (Exception ex){
            Log.d(null, ex.getClass() + " error: " + ex.getMessage());
            throw ex;
        }

        return num;
    }

    public ArrayList<Library> listLibraries() {
        ArrayList<Library> list = new ArrayList<>();
        Cursor cursor = mDataBase.rawQuery("SELECT * FROM library", null);
        cursor.moveToFirst();
        int[] i = new int[]{ cursor.getColumnIndex("lId"), cursor.getColumnIndex("lName"),
                cursor.getColumnIndex("lCityNumber"), cursor.getColumnIndex("lEmail"),
                cursor.getColumnIndex("lAddress")};
        while (!cursor.isAfterLast()){
            list.add(new Library(cursor.getInt(i[0]), cursor.getString(1), cursor.getString(2), cursor.getString(3),
                    cursor.getString(4)));
            cursor.moveToNext();
        }

        cursor.close();
        return list;
    }

    @NotNull
    public Long insertSubscriber(@NotNull User user, @NotNull Subscriber subscriber, int idLib) throws Exception {
        long num = 0;
        try{
            mDataBase.beginTransaction();

            ContentValues newDataForUser = new ContentValues();
            newDataForUser.put("uLogin", user.getLogin());
            newDataForUser.put("uEmail", user.getEmail());
            newDataForUser.put("uPass", user.getPassword());
            newDataForUser.put("uLibId", idLib);
            num += mDataBase.insert("userSystem", null, newDataForUser);

            ContentValues newDataForSubs = new ContentValues();
            newDataForSubs.put("sFirstname", subscriber.getFirstName());
            newDataForSubs.put("sSecondname", subscriber.getSecondName());
            newDataForSubs.put("sLastname", subscriber.getLastName());
            newDataForSubs.put("sPhNumber", subscriber.getPhoneNumber());
            newDataForSubs.put("sEmail", subscriber.getEmailS());
            newDataForSubs.put("sAddress", subscriber.getAddress());
            num += mDataBase.insert("subscriber", null, newDataForSubs);

            Cursor cursor = mDataBase.rawQuery("Select max(snSubsNumber) from subsNumber " +
                    "where snLibId = '" + idLib + "'", null);
            cursor.moveToFirst();
            int subsNum = cursor.getInt(0) + 1;

            cursor = mDataBase.rawQuery("Select sId from subscriber " +
                    "where sPhNumber = '" + subscriber.getPhoneNumber() + "'", null);
            cursor.moveToFirst();
            int idSubs = cursor.getInt(0);

            ContentValues newDataForSubsNum = new ContentValues();
            newDataForSubsNum.put("snSubsNumber", subsNum);
            newDataForSubsNum.put("snLibId", idLib);
            newDataForSubsNum.put("snSubsId", idSubs);
            num += mDataBase.insert("subsNumber", null, newDataForSubsNum);

            mDataBase.setTransactionSuccessful();
            mDataBase.endTransaction();
        }catch (Exception ex){
            Log.d(null, ex.getClass() + " error: " + ex.getMessage());
            throw ex;
        }
        return num;
    }

    @NotNull
    public ArrayList<SubsNum> listSubsNums(@Nullable Subscriber subscriber) {
        ArrayList<SubsNum> list = new ArrayList<>();
        if (subscriber != null){
            Cursor cursor = mDataBase.rawQuery("SELECT * FROM subsNumber " +
                    "join library on snLibId = lId where snSubsId = '" + subscriber.getId() + "' and snRelevance = '1'", null);
            cursor.moveToFirst();
            int[] i = new int[]{ cursor.getColumnIndex("lId"), cursor.getColumnIndex("lName"),
                    cursor.getColumnIndex("lCityNumber"), cursor.getColumnIndex("lEmail"),
                    cursor.getColumnIndex("lAddress"), cursor.getColumnIndex("snId"), cursor.getColumnIndex("snSubsNumber")};
            while (!cursor.isAfterLast()){
                list.add(new SubsNum(cursor.getInt(i[5]), new Library(cursor.getInt(i[0]), cursor.getString(i[1]), cursor.getString(i[2]),
                        cursor.getString(i[3]), cursor.getString(i[4])), cursor.getInt(i[6])));
                cursor.moveToNext();
            }

            cursor.close();
        }

        return list;
    }

    public boolean checkPassword(@Nullable User user, @NotNull String pass) {
        Cursor cursor = mDataBase.rawQuery("SELECT * FROM userSystem where uEmail = '"+user.getEmail()+"' and uPass = '"+pass+"'" , null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            return true;
        }

        cursor.close();

        return false;
    }

    public long updatePassword(@Nullable User user, @NotNull String pass) {
        long num = 0;
        ContentValues passUpdateUser = new ContentValues();
        passUpdateUser.put("uPass", pass);
        String where = "uEmail = '" + user.getEmail() + "'";
        num += mDataBase.update("userSystem", passUpdateUser, where, null);

        return num;
    }

    public long updateLogin(@Nullable User user, @NotNull String login) {
        long num = 0;
        ContentValues loginUpdateUser = new ContentValues();
        loginUpdateUser.put("uLogin", login);
        String where = "uEmail = '" + user.getEmail() + "'";
        num += mDataBase.update("userSystem", loginUpdateUser, where, null);

        return num;
    }

    public long updateEmail(@Nullable User user, @NotNull String email) throws Exception{
        long num = 0;

        try {
            mDataBase.beginTransaction();

            ContentValues lodinUpdateUser = new ContentValues();
            lodinUpdateUser.put("uLogin", user.getLogin().concat("_"));
            String where = "uEmail = '" + user.getEmail() + "'";
            num += mDataBase.update("userSystem", lodinUpdateUser, where, null);

            ContentValues insertUser = new ContentValues();
            insertUser.put("uLogin", user.getLogin());
            insertUser.put("uEmail", email);
            insertUser.put("uPass", user.getPassword());
            num += mDataBase.insert("userSystem", null, insertUser);

            if (num >0){
                Cursor cursor = mDataBase.rawQuery("SELECT uId FROM userSystem where uEmail = " + email, null);
                cursor.moveToFirst();
                int idNewUser = cursor.getInt(0);
                cursor.close();

                ContentValues emailUpdateSubs = new ContentValues();
                emailUpdateSubs.put("sEmail", email);
                where = "sEmail = '" + user.getEmail() + "'";
                num += mDataBase.update("subscriber", emailUpdateSubs, where, null);

                ContentValues userUpdateBasket = new ContentValues();
                userUpdateBasket.put("bUserID", idNewUser);
                where = "bUserID = '" + user.getId() + "'";
                num += mDataBase.update("basket", userUpdateBasket, where, null);

                where = "uEmail = '"+ user.getEmail()+"'";
                num += mDataBase.delete("userSystem", where, null);
            }
            mDataBase.setTransactionSuccessful();
            mDataBase.endTransaction();
        }catch (Exception ex){
            Log.d(null, ex.getClass() + " error: " + ex.getMessage());
            throw ex;
        }

        return num;
    }

    @NotNull
    public long updatePhNumber(Subscriber subscriber, @NotNull String phoneNumber) {
        long num = 0;
        ContentValues phNumUpdateSubs = new ContentValues();
        phNumUpdateSubs.put("sPhNumber", phoneNumber);
        String where = "sId = '" + subscriber.getId() + "'";
        num += mDataBase.update("subscriber", phNumUpdateSubs, where, null);
        return num;
    }

    public long editSubscriber(@NotNull Subscriber subscriber) {
        long num = 0;
        ContentValues updateSubs = new ContentValues();
        updateSubs.put("sFirstname", subscriber.getFirstName());
        updateSubs.put("sSecondname", subscriber.getSecondName());
        updateSubs.put("sLastname", subscriber.getLastName());
        updateSubs.put("sAddress", subscriber.getAddress());
        String where = "sId = '" + subscriber.getId() + "'";
        num += mDataBase.update("subscriber", updateSubs, where, null);
        return num;
    }

    @NotNull
    public Library findLibraryById(int id) {
        Cursor cursor = mDataBase.rawQuery("SELECT * FROM Library " +
                "where lId = '" + id + "'", null);
        cursor.moveToFirst();
        if (!cursor.isAfterLast()){
            int[] i_cursor = new int[]{cursor.getColumnIndex("lId"), cursor.getColumnIndex("lName"), cursor.getColumnIndex("lCityNumber"),
                    cursor.getColumnIndex("lEmail"), cursor.getColumnIndex("lAddress") };

            Library library = new Library(cursor.getInt(i_cursor[0]), cursor.getString(i_cursor[1]), cursor.getString(i_cursor[2]),
                    cursor.getString(i_cursor[3]), cursor.getString(i_cursor[4]));
            cursor.moveToNext();
            cursor.close();
            return library;
        }

        return null;
    }

    @NotNull
    public Catalog findEditionById(int id) {
        Cursor cursor = mDataBase.rawQuery("SELECT * FROM Book " +
                "join edition on bId = eBookId " +
                "left join cycle on bCycleId = cId " +
                "join bookauthor on baBookId = bId "+
                "join author on aId = baAuthorId where eId = '" + id + "'", null);
        cursor.moveToFirst();
        if (!cursor.isAfterLast()){
            Catalog catalog = new Catalog(cursor.getInt(4), cursor.getString(10),
                    cursor.getInt(12), cursor.getString(6), cursor.getInt(9),
                    cursor.getDouble(7), cursor.getString(1), cursor.getString(14), cursor.getString(5));
            catalog.setImage(convertNameFileToIdForDrawble(cursor.getString(8)));
            while (!cursor.isAfterLast()) {
                Author author = new Author(cursor.getString(19),cursor.getString(20),cursor.getString(21));
                catalog.addAuthorToNameAuthors(author);
                cursor.moveToNext();
            }
            cursor.close();
            return catalog;
        }

        return null;
    }

    @NotNull
    public ArrayList<NumInLib> listEditionIsLib(int idEdition, Subscriber subscriber) {
        ArrayList<NumInLib> list = new ArrayList<>();

        Cursor cLibs = mDataBase.rawQuery("select dlLibId, count(cbId) from DepartmentLibrary " +
                "left join copyBook on dlId = cbDLId " +
                "where cbEditionId = '"+idEdition+"' and cbStatus == 'в наличии' " +
                "GROUP by dlLibId", null);

        Map<Integer, Integer> map = new HashMap<Integer, Integer>();
        cLibs.moveToFirst();
        while (!cLibs.isAfterLast()){
            if (cLibs.getInt(1) > 0){
                map.put(cLibs.getInt(0), cLibs.getInt(1));
            }
            cLibs.moveToNext();
        }
        cLibs.close();

        if (subscriber != null) {
            ArrayList<SubsNum> listSN = listSubsNums(subscriber);
            for (Map.Entry<Integer, Integer> m : map.entrySet()) {
                boolean find = false;
                for (SubsNum s : listSN) {
                    if (m.getKey() == s.getLibrary().getId()) {
                        list.add(new NumInLib(m.getValue(), s.getLibrary(), true));
                        find = true;
                        break;
                    }
                }
                if (!find) {
                    Library library = findLibraryById(m.getKey());
                    list.add(new NumInLib(m.getValue(), library, false));
                }
            }
        }else{
            for (Map.Entry<Integer, Integer> m : map.entrySet()) {
                Library library = findLibraryById(m.getKey());
                list.add(new NumInLib(m.getValue(), library, false));
            }
        }

        return list;
    }

    @NotNull
    public ArrayList<Basket> listBasket(@Nullable User user) {
        ArrayList<Basket> list = new ArrayList<Basket>();
        Cursor cBasketList = mDataBase.rawQuery("select * from Basket " +
                "where bNumCB > 0 and bUserId = '" + user.getId() + "'", null);

        cBasketList.moveToFirst();
        int[] i_basketList = new int[]{
                cBasketList.getColumnIndex("bId"), cBasketList.getColumnIndex("bFavorite"),
                cBasketList.getColumnIndex("bNumCB"), cBasketList.getColumnIndex("bEditionId"),
                cBasketList.getColumnIndex("bLibId")};
        while (!cBasketList.isAfterLast()){
            boolean isFavorite = cBasketList.getInt(i_basketList[1]) > 0;
            Catalog catalog = findEditionById(cBasketList.getInt(i_basketList[3]));
            Library library = findLibraryById(cBasketList.getInt(i_basketList[4]));
            Basket basket = new Basket(cBasketList.getInt(i_basketList[0]), catalog,
                    cBasketList.getInt(i_basketList[2]),false, isFavorite, library);
            list.add(basket);
            cBasketList.moveToNext();
        }
        cBasketList.close();
        return list;
    }

    public long updateFavoriteBasket(@NotNull Basket basket) {
        long num = 0;
        int favorite=1;
        if(basket.isFavorite()) favorite = 0;
        if (basket.getNum() > 0){
            ContentValues favoriteUpdateBasket = new ContentValues();
            favoriteUpdateBasket.put("bFavorite", favorite);
            String where = "bId = '" + basket.getId() + "'";
            num = mDataBase.update("basket", favoriteUpdateBasket, where, null);
        }else{
            String where = "bId = '" + basket.getId();
            num += mDataBase.delete("basket", where, null);
        }

        return num;
    }

    public long insertBasket(Basket basket, @NotNull User user, @Nullable Library selectLib) {
        try {
            mDataBase.beginTransaction();
            long num = 0;
            Library library;
            if (selectLib != null)
                library = selectLib;
            else
                library = user.getLibrary();

            Cursor cNumCB = mDataBase.rawQuery("select bNumCB, bId from basket " +
                    "where bUserId = '"+ user.getId() + "' and bEditionId = '"+ basket.getCatalog().getIdEdition()+"' and " +
                    "bLibId = '" + library.getId() + "'" , null);
            cNumCB.moveToFirst();
            if(cNumCB.getCount()>0 && cNumCB.getInt(0)>0){
                int numCBOfEdition = cNumCB.getInt(0);
                int idB = cNumCB.getInt(1);
                cNumCB.close();
                ContentValues numCBUpdateBasket = new ContentValues();
                numCBUpdateBasket.put("bNumCB", numCBOfEdition+1);
                String where = "bId = '" + idB + "'";
                num = mDataBase.update("basket", numCBUpdateBasket, where, null);

            }else{
                ContentValues insertBasket = new ContentValues();
                insertBasket.put("bFavorite", basket.isFavorite());
                insertBasket.put("bUserId", user.getId());
                insertBasket.put("bEditionId", basket.getCatalog().getIdEdition());
                insertBasket.put("bLibId", library.getId());
                insertBasket.put("bNumCB", 1);
                num = mDataBase.insert("basket",null, insertBasket);
            }
            mDataBase.setTransactionSuccessful();
            mDataBase.endTransaction();
            return num;
        }catch (Exception ex){
            throw ex;
        }
    }

    @NotNull
    public ArrayList<Catalog> listFavorites(@Nullable User user) {
        ArrayList<Catalog> list = new ArrayList<Catalog>();
        Cursor cursor = mDataBase.rawQuery("SELECT * FROM Book " +
                "join edition on Book.bId = eBookId " +
                "left join cycle on bCycleId = cId " +
                "join bookauthor on baBookId = book.bId "+
                "join author on aId = baAuthorId " +
                "join basket on basket.bEditionId = eId " +
                "where bFavorite = 1 and bUserId = " + user.getId(), null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()) {
            Author author = new Author(cursor.getString(19),cursor.getString(20),cursor.getString(21));
            boolean find = false;
            for (Catalog query:list) {
                if (query.getIdEdition() == Integer.valueOf(cursor.getString(4))){
                    query.addAuthorToNameAuthors(author);
                    find = true;
                    break;
                }
            }
            if (!find){
                ArrayList<Author> list1 = new ArrayList<Author>();
                list1.add(author);
                int num = cursor.getColumnCount();
                Catalog catalog = new Catalog(cursor.getInt(4), cursor.getString(10),
                        cursor.getInt(12), cursor.getString(6), cursor.getInt(9),
                        cursor.getDouble(7), cursor.getString(1), cursor.getString(14), cursor.getString(5));
                catalog.setImage(convertNameFileToIdForDrawble(cursor.getString(8)));
                catalog.addAuthorToNameAuthors(author);
                list.add(catalog);
            }
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }

    public long updateFavoriteBasket(@NotNull Catalog catalog, @Nullable User user) {
        long num = 0;
        Cursor cursor = mDataBase.rawQuery("Select bNUmCB from basket " +
                "where bEditionId = '" + catalog.getIdEdition() + "' and bUserId = " + user.getId(), null);
        cursor.moveToFirst();
        int numCB = cursor.getInt(0);
        if (numCB == 0){
            String where = "bEditionId = '" + catalog.getIdEdition() + "' and bUserId = " + user.getId();
            num += mDataBase.delete("basket", where, null);
        }else{
            ContentValues favoriteUpdateBasket = new ContentValues();
            favoriteUpdateBasket.put("bFavorite", 0);
            String where = "bEditionId = '" + catalog.getIdEdition() + "' and bUserId = " + user.getId();
            num += mDataBase.update("basket", favoriteUpdateBasket, where, null);
        }


        return num;
    }

    @NotNull
    public ArrayList<Reservation> listReservation(@Nullable User user) {
        ArrayList<Reservation> list = new ArrayList<Reservation>();
        Cursor cursor = mDataBase.rawQuery("select reId, rDateForm, rDateReserv, rLibId, eId, rStatus from reservation " +
                "join reservationEdition on reResId = rId join copyBook on cbId = reCBId " +
                "join edition on reEditionId = eId " +
                "where rSubId = " + user.getSubscriber().getId() +
                " order by eId, rStatus", null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            Library library = findLibraryById(cursor.getInt(3));
            Catalog catalog = findEditionById(cursor.getInt(4));
            if (library != null && catalog != null){
                list.add(new Reservation(cursor.getInt(0), cursor.getString(1), cursor.getString(2),
                        library, catalog, cursor.getString(5)));
            }
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }

    @NotNull
    public ArrayList<HistoryReader> listHR(@Nullable User user, @NotNull String where) {
        ArrayList<HistoryReader> list = new ArrayList<HistoryReader>();
        Cursor cursor = mDataBase.rawQuery("select hrId, cbEditionId, hrRelevance, hrDateIssue, hrDateReturn, cbInvNumber, lId from historyReader " +
                "join copyBook on hrCBId = cbId join DepartmentLibrary on cbDLId = dlId join library on dlLibId = lId " +
                "where cbStatus != 'бронь' and cbStatus != 'списано' and hrSubsId = '" + user.getSubscriber().getId() + "' and " + where, null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            Library library = findLibraryById(cursor.getInt(6));
            Catalog catalog = findEditionById(cursor.getInt(1));
            boolean relevance = cursor.getInt(2) == 1;
            list.add(new HistoryReader(cursor.getInt(0), cursor.getString(3), cursor.getString(4), cursor.getInt(5), relevance, library,
                    catalog));
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }

    @RequiresApi(api = Build.VERSION_CODES.O)
    public long updateDateReturnHR(@NotNull HistoryReader hr) {
        long num = 0;
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate localDate = LocalDate.parse(hr.getDateReturn(), formatter);
        localDate = LocalDate.from(localDate).plusMonths(1);

        ContentValues dateReturnUpdateHR = new ContentValues();
        dateReturnUpdateHR.put("hrDateReturn", localDate.toString());
        String where = "hrId = '" + hr.getId() + "'";
        num = mDataBase.update("historyReader", dateReturnUpdateHR, where, null);

        return num;
    }

    public long updateLibUser(int idDefaultLib, User user) {
        long num = 0;
        ContentValues libUpdateUser = new ContentValues();
        libUpdateUser.put("uLibId", idDefaultLib);
        String where = "uId = '" + user.getId() + "'";
        num += mDataBase.update("userSystem", libUpdateUser, where, null);
        return num;
    }

    public long deleteBasket(@NotNull Basket basket) {
        long num = 0;
        Cursor cursor = mDataBase.rawQuery("select bFavorite from basket where bId = " + basket.getId(), null);
        cursor.moveToFirst();
        if (cursor.getInt(0) == 1){
            ContentValues updateBasket = new ContentValues();
            updateBasket.put("bNumCB", 0);
            String where = "bId = '" + basket.getId() + "'";
            num += mDataBase.update("basket", updateBasket, where, null);
        }else{
            String where = "bId = '" + basket.getId() + "'";
            num = mDataBase.delete("basket", where, null);
        }
        return num;
    }

    @NotNull
        public Basket findBasketById(int it) {
        Cursor cursor = mDataBase.rawQuery(
                "select bId, bNumCB, bFavorite, bEditionId, bLibId  from Basket " +
                "where bId = '" + it + "'", null);

        cursor.moveToFirst();
        boolean isFavorite = cursor.getInt(2) > 0;
        Catalog catalog = findEditionById(cursor.getInt(3));
        Library library = findLibraryById(cursor.getInt(4));
        Basket basket = new Basket(cursor.getInt(0), catalog,
                cursor.getInt(1),false, isFavorite, library);
        return basket;
    }

    public boolean checkNumEditionInLib(@NotNull Basket basket) {
        Cursor cursor = mDataBase.rawQuery("select dlLibId, count(cbId) from DepartmentLibrary " +
                "left join copyBook on dlId = cbDLId where cbEditionId = '"+basket.getCatalog().getIdEdition()+"' " +
                "and cbStatus == 'в наличии' and dlLibId = '"+basket.getLibrary().getId()+"' " +
                "GROUP by dlLibId", null);

        cursor.moveToFirst();
        return cursor.getInt(1)>=basket.getNum();
    }

    public long insertReservation(@NotNull ArrayList<ReservationPrewie> list, @NotNull User user) {
        long num = 0;
        try {
            mDataBase.beginTransaction();

            for (ReservationPrewie item1:list) {
                ContentValues insertReservation = new ContentValues();
                insertReservation.put("rSubId", user.getSubscriber().getId());
                insertReservation.put("rLibId", item1.getLibrary().getId());
                num += mDataBase.insert("reservation",null, insertReservation);

                String date = "";
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    date = LocalDate.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"));
                }

                Cursor cIdInsertReserv = mDataBase.rawQuery("select max(rId) from reservation " +
                        "where rSubId = '"+ user.getSubscriber().getId() +"' and rLibId = '"+item1.getLibrary().getId()+"' " +
                        "and rDateForm = '"+date+"'", null);
                cIdInsertReserv.moveToFirst();
                int idReserv = cIdInsertReserv.getInt(0);
                cIdInsertReserv.close();

                for (Basket b : item1.getList() ) {
                    Cursor cursor = mDataBase.rawQuery("select cbId from copyBook " +
                            "join DepartmentLibrary on dlId = cbDLId " +
                            "where cbEditionId = '"+ b.getCatalog().getIdEdition()+"' and " +
                            "dlLibId = '"+item1.getLibrary().getId()+"' LIMIT " + b.getNum(), null);
                    cursor.moveToFirst();
                    if (cursor.getCount() == b.getNum()){
                            ContentValues insertReservEdition = new ContentValues();
                            insertReservEdition.put("reResId", idReserv);
                            insertReservEdition.put("reEditionId", b.getCatalog().getIdEdition());
                            num += mDataBase.insert("reservationEdition",null, insertReservEdition);
                        cursor.close();
                        num += deleteBasket(b);
                    }else{
                        cursor.close();
                        mDataBase.setTransactionSuccessful();
                        mDataBase.endTransaction();
                        return 0;
                    }
                }

            }
            mDataBase.setTransactionSuccessful();
            mDataBase.endTransaction();
        }catch (Exception ex){
            String error = ex.getMessage();
        }

        return num;
    }

    public long insertRequest(@NotNull Library library, @NotNull Catalog edition, @Nullable Subscriber subscriber) {
        ContentValues insertRequest = new ContentValues();
        insertRequest.put("reqLibId", library.getId());
        insertRequest.put("reqSubId", subscriber.getId());
        insertRequest.put("reqEditionId", edition.getIdEdition());
        long num = mDataBase.insert("request",null, insertRequest);
        return num;
    }

    @NotNull
    public ArrayList<Request> listRequest(@Nullable Subscriber subscriber) {
        ArrayList<Request> list = new ArrayList<>();
        Cursor cursor = mDataBase.rawQuery("select reqId, reqStatus, reqLibId, reqEditionId from request " +
                "where reqSubId = " + subscriber.getId(),null);
        cursor.moveToFirst();
        while (!cursor.isAfterLast()){
            Library library = findLibraryById(cursor.getInt(2));
            Catalog edition = findEditionById(cursor.getInt(3));
            Request request = new Request(cursor.getInt(0), cursor.getString(1), library, edition);
            list.add(request);
            cursor.moveToNext();
        }
        cursor.close();
        return list;
    }

    public long deleteReservation(@NotNull Reservation reservation) {
        String where = "rId = '" + reservation.getId() + "'";
        long num = mDataBase.delete("reservation", where, null);
        return num;
    }

    public Basket getFavoritesByEditionForUser(@NotNull Catalog edition, @Nullable User user) {
        Cursor cursor = mDataBase.rawQuery("select bId from basket " +
                "where bEditionId = '"+edition.getIdEdition()+"' and bUserId = '"+user.getId()+"' LIMIT 1", null);
        cursor.moveToFirst();

        if (cursor.getCount() > 0){
            Basket basket = findBasketById(cursor.getInt(0));
            cursor.close();
            return basket;
        }

        return null;
    }

    public long insertFavoriteBasket(@NotNull Basket basket, @NotNull User user) {
        try {
            mDataBase.beginTransaction();
            long num = 0;

            Cursor cNumCB = mDataBase.rawQuery("select bNumCB, bId, bFavorite from basket " +
                    "where bUserId = '"+ user.getId() + "' and bEditionId = '"+ basket.getCatalog().getIdEdition()+"' and " +
                    "bLibId = '" + user.getLibrary().getId() + "'" , null);
            cNumCB.moveToFirst();
            if (cNumCB.getCount()>0){
                int numCB = cNumCB.getInt(0);
                if (numCB > 0){
                    ContentValues updateBasket = new ContentValues();
                    updateBasket.put("bFavorite", 1);
                    String where = "bId = '" + cNumCB.getInt(1) + "'";
                    num += mDataBase.update("basket", updateBasket, where, null);
                }
            }else{
                ContentValues insertBask = new ContentValues();
                insertBask.put("bFavorite", 1);
                insertBask.put("bNumCB", 0);
                insertBask.put("bUserId", user.getId());
                insertBask.put("bEditionId", basket.getCatalog().getIdEdition());
                insertBask.put("bLibId", user.getLibrary().getId());
                num += mDataBase.insert("basket",null, insertBask);
            }
            mDataBase.setTransactionSuccessful();
            mDataBase.endTransaction();
            return num;
        }catch (Exception ex){
            throw ex;
        }

    }
}
