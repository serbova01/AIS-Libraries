package com.example.pw3.Adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.R
import com.example.pw3.models.NumInLib
import com.example.pw3.models.SubsNum

class ItemLibRegSusbAdapter(var list:ArrayList<SubsNum>)  :
    RecyclerView.Adapter<ItemLibRegSusbAdapter.ItemLibRegSusbHolder>(){

    var onItemChecked: ((SubsNum, CheckBox) -> Unit)? = null

    inner class ItemLibRegSusbHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val checkBox: CheckBox = itemView.findViewById(R.id.cb_requestItem)
        val textView_name : TextView = itemView.findViewById(R.id.tv_requestItem_name)
        val textView_address : TextView = itemView.findViewById(R.id.tv_requestItem_address)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemLibRegSusbHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_lib_reg_subs_layout, parent, false)
        return ItemLibRegSusbHolder(view)
    }

    override fun onBindViewHolder(holder: ItemLibRegSusbHolder, position: Int) {
        var item = list[position]
        holder.textView_name.text = item.library.nameL
        holder.textView_address.text = item.library.address
        holder.checkBox.setOnClickListener(){
            onItemChecked?.invoke(item, holder.checkBox)
        }
        holder.checkBox.isChecked = item.isSelect

    }

    fun setActiveQuery(item: SubsNum) {
        for (l in list)
            l.isSelect = l.library.id == item.library.id

        notifyDataSetChanged()
    }

    override fun getItemCount(): Int {
        return  list.size
    }


}