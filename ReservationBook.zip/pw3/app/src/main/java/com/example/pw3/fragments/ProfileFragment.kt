package com.example.pw3.fragments

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.appcompat.widget.AppCompatButton
import com.example.pw3.*
import com.example.pw3.models.User
import com.example.pw3.profile.FavoritesListActivity
import com.example.pw3.profile.HistoryReaderListActivity
import com.example.pw3.profile.RequestListActivity
import com.example.pw3.profile.ReservListActivity


class ProfileFragment : Fragment() {

    lateinit var mSettings: SharedPreferences
    private lateinit var mDBHelper: Server
    var user: User? = null
    var is_logged:Boolean = false

    private lateinit var tv_user:TextView
    lateinit var tv_profile_authorize:TextView
    lateinit var btn_editProfile:AppCompatButton
    lateinit var tv_frProfile_favorites:TextView
    lateinit var tv_request:TextView
    lateinit var tv_reservation:TextView
    lateinit var tv_historyReader:TextView
    lateinit var btn_exit:AppCompatButton

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.fragment_profile, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        requireActivity().title = getString(R.string.profile)

        init(view)
    }

    private fun init(view: View) {
        //connect(view)
        mDBHelper = Server(this.context)
        mDBHelper.connect()
        mSettings = this.context?.getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        is_logged = mSettings!!.getBoolean("is_logged", false)
        var email = ""
        initComponents(view)

        if (is_logged){
            mDBHelper = Server(this.context)
            mDBHelper.connect()
            email = mSettings!!.getString("email", "").toString()
            //subscriber = list_subs.first{it.emailS == email}
            user = mDBHelper.findUserByEmail(email)

            if (user != null){
                tv_user.text = user!!.login
                btn_exit.visibility = AppCompatButton.VISIBLE
            }
            else{
                noAction()
            }
        }else{
            noAction()
        }
    }

    private fun noAction() {
        tv_profile_authorize.visibility = TextView.VISIBLE
        btn_exit.visibility = AppCompatButton.INVISIBLE
        btn_editProfile.visibility = AppCompatButton.INVISIBLE
    }

    private fun initComponents(view: View) {
        tv_profile_authorize = view.findViewById(R.id.tv_frProfile_authorize)
        tv_profile_authorize.setOnClickListener(){
            onOpenLogin()
        }
        btn_editProfile = view.findViewById(R.id.btn_frProfile_editProfile)
        btn_editProfile.setOnClickListener(){
            onOpenProfile()
        }
        tv_frProfile_favorites = view.findViewById(R.id.tv_frProfile_favorites)
        tv_request= view.findViewById(R.id.tv_frProfile_request)
        tv_historyReader= view.findViewById(R.id.tv_frProfile_historyReader)
        tv_reservation= view.findViewById(R.id.tv_frProfile_reservation)
        tv_reservation.setOnClickListener(){
            onOpenReservationList()
        }
        tv_frProfile_favorites.setOnClickListener(){
            onOpenListFavorites()
        }
        tv_request.setOnClickListener(){
            onOpenListRequests()
        }
        tv_historyReader.setOnClickListener(){
            onOpenHistoriesReader()
        }
        btn_exit = view.findViewById(R.id.btn_frProfile_exit)
        btn_exit.setOnClickListener(){
            onExitProfile()
        }
        tv_user = view.findViewById(R.id.tv_user)
    }

    private fun onOpenHistoriesReader() {
        if (user != null){
            val intent = Intent(context, HistoryReaderListActivity::class.java)
            //intent.putExtra("user", user)
            startActivity(intent)
        }
    }

    private fun onOpenReservationList() {
        if (user != null){
            val intent = Intent(context, ReservListActivity::class.java)
            //intent.putExtra("user", user)
            startActivity(intent)
        }
    }

    fun onOpenProfile(){
        if (user != null){
            val intent = Intent(context, ProfileActivity::class.java)
            //intent.putExtra("user", user)
            startActivity(intent)
        }
    }

    fun onOpenLogin(){
        val intent = Intent(context, LoginActivity::class.java)
        startActivity(intent)
    }
    companion object {
        @JvmStatic
        fun newInstance() = ProfileFragment()
    }

    fun onExitProfile() {
        mSettings = this.context?.getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        val editor = mSettings.edit()
        editor.putBoolean("is_logged", false).apply()
        val intent = Intent(context, LoginActivity::class.java)
        startActivity(intent)
    }
    fun onOpenListRequests() {
        if (user != null){
            val intent = Intent(context, RequestListActivity::class.java)
            startActivity(intent)
        }
    }
    fun onOpenListFavorites() {
        if (user != null){
            val intent = Intent(context, FavoritesListActivity::class.java)
            startActivity(intent)

        }
    }
}