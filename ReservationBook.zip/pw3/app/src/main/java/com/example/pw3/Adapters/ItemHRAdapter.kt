package com.example.pw3.Adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.R
import com.example.pw3.models.HistoryReader

class ItemHRAdapter(val historyReader: ArrayList<HistoryReader>):
    RecyclerView.Adapter<ItemHRAdapter.ItemHRHolder>() {

    var onItemClick: ((HistoryReader) -> Unit)? = null

    inner class ItemHRHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val imageView : ImageView = itemView.findViewById(R.id.iv_alsoHRItemItem_imageEd)
        val tv_title : TextView = itemView.findViewById(R.id.tv_alsoHRItem_titleBook)
        val tv_discription: TextView = itemView.findViewById(R.id.tv_alsoHRItem_discriptionBook)
        val tv_dateIssue : TextView = itemView.findViewById(R.id.tv_alsoHRItem_dateIssue)
        val tv_dateReturn : TextView = itemView.findViewById(R.id.tv_alsoHRItem_dateReturn)
        val tv_libName : TextView = itemView.findViewById(R.id.tv_alsoHRItem_libName)
        val tv_libAddress : TextView = itemView.findViewById(R.id.tv_alsoHRItem_libAddress)
        val tv_invNumber : TextView = itemView.findViewById(R.id.tv_alsoHRItem_invNumber)
        init {
            itemView.setOnClickListener(){
                onItemClick?.invoke(historyReader[adapterPosition])
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemHRHolder {
        var view = LayoutInflater.from(parent.context).inflate(R.layout.item_hr_layout, parent, false)
        return ItemHRHolder(view)
    }

    override fun onBindViewHolder(holder: ItemHRHolder, position: Int) {
        val item = historyReader[position]
        item.edition.image?.let { holder.imageView.setImageResource(it) }
        holder.tv_title.text = item.edition.nameBook
        holder.tv_discription.text = item.edition.getShortText()

        holder.tv_dateIssue.text = addText(holder.tv_dateIssue, item.dateIssue)
        holder.tv_dateReturn.text = addText(holder.tv_dateReturn, item.dateReturn)
        holder.tv_libName.text = item.library.nameL
        holder.tv_libAddress.text = item.library.address
        holder.tv_invNumber.text = addText(holder.tv_invNumber, item.invNum.toString())
    }

    override fun getItemCount(): Int {
        return historyReader.size
    }

    fun addText(textView: TextView, text:String):String{
        return textView.text.toString() + ": " + text
    }
}