package com.example.pw3.models

class SubsNum (id:Int, library: Library, activeNumber:Int){
    var id = id
    var library = library
    var activeNumber = activeNumber
    var isSelect = false
}