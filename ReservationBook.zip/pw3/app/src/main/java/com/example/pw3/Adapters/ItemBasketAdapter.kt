package com.example.pw3.Adapters

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.widget.AppCompatButton
import androidx.recyclerview.widget.RecyclerView
import com.example.pw3.R
import com.example.pw3.models.Basket


class ItemBasketAdapter(var basket:ArrayList<Basket>):
    RecyclerView.Adapter<ItemBasketAdapter.ItemBasketViewHolder>() {
    var onItemClickReservation: ((Basket) -> Unit)? = null
    var onItemClickDelete: ((Basket) -> Unit)? = null
    var onItemClickFavorite: ((Basket) -> Unit)? = null
    var onItemClickSelected: ((Basket) -> Unit)? = null
    var onItemClick: ((Basket) -> Unit)? = null
    lateinit var view:View

    inner class ItemBasketViewHolder(itemView: View): RecyclerView.ViewHolder(itemView){
        val imageView : ImageView = itemView.findViewById(R.id.iv_basket_imageItem)
        val textView_title : TextView = itemView.findViewById(R.id.tv_basket_nameItem)
        val textView_text : TextView = itemView.findViewById(R.id.tv_basket_discriptionItem)
        val numberPicker: NumberPicker = itemView.findViewById(R.id.np_basket_number)
        val buttonReserv:AppCompatButton = itemView.findViewById(R.id.btn_basket_reservation)
        val checkBox:CheckBox = itemView.findViewById(R.id.cb_basket_isSelect)
        val buttonFavorite: ImageButton = itemView.findViewById(R.id.btn_basket_favorite)
        val buttonDelete:ImageButton = itemView.findViewById(R.id.btn_basket_delete)
        init {
            itemView.setOnClickListener(){
                onItemClick?.invoke(basket[adapterPosition])
            }
            buttonReserv.setOnClickListener(){
                basket[adapterPosition].num = numberPicker.value
                onItemClickReservation?.invoke(basket[adapterPosition])
            }
            checkBox.setOnClickListener(){
                basket[adapterPosition].isSelect = checkBox.isChecked
                basket[adapterPosition].num = numberPicker.value
                onItemClickSelected?.invoke(basket[adapterPosition])
            }
            buttonFavorite.setOnClickListener(){
                onItemClickFavorite?.invoke(basket[adapterPosition])
                if(basket[adapterPosition].isFavorite){
                    buttonFavorite.setImageResource(R.drawable.ic_favorite_on)
                }else
                    buttonFavorite.setImageResource(R.drawable.ic_favorite_off)
            }
            buttonDelete.setOnClickListener(){
                onItemClickDelete?.invoke(basket[adapterPosition])
                basket.remove(basket[adapterPosition])
                notifyItemRemoved(position)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemBasketViewHolder {
        view = LayoutInflater.from(parent.context).inflate(R.layout.item_basket_layout, parent, false)

        return ItemBasketViewHolder(view)
    }

    override fun onBindViewHolder(holder: ItemBasketViewHolder, position: Int) {
        var item = basket[position]
        item.catalog.image?.let { holder.imageView.setImageResource(it) }
        holder.textView_title.text = item.catalog.nameBook
        holder.textView_text.text = item.catalog.getShortText()
        holder.numberPicker.minValue = 1
        holder.numberPicker.maxValue = item.num+1
        holder.numberPicker.value = item.num
        holder.buttonFavorite.setImageResource(item.id_imgFavorite)
        holder.buttonDelete.visibility = ImageButton.VISIBLE
    }

    override fun getItemCount(): Int {
        return basket.size
    }
}