package com.example.pw3

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationCompat
import androidx.fragment.app.Fragment
import com.example.pw3.fragments.BasketFragment
import com.example.pw3.fragments.CatalogFragment
import com.example.pw3.fragments.ProfileFragment
import com.example.pw3.models.User
import com.example.pw3.profile.HistoryReaderListActivity
import com.google.android.material.bottomnavigation.BottomNavigationView
import java.time.LocalDateTime
import java.time.format.DateTimeFormatter


class MainActivity : AppCompatActivity() {

    val catalogFragment = CatalogFragment()
    val basketFragment = BasketFragment()
    val profileFragment = ProfileFragment()

    private lateinit var mDBHelper: Server
    lateinit var mSettings: SharedPreferences
    var user: User? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        mSettings = this.getSharedPreferences("my_storage", Context.MODE_PRIVATE) as SharedPreferences
        mDBHelper = Server(this)
        mDBHelper.connect()

        val is_logged = mSettings!!.getBoolean("is_logged", false)
        if (is_logged){
            val email:String = mSettings!!.getString("email", "").toString()
            user = mDBHelper.findUserByEmail(email)
            if (user != null){
                Toast.makeText(this, String.format("Пользователь $email авторизирован"), Toast.LENGTH_SHORT).show()
                setNotifications()
            }else{
                var editor = mSettings.edit()
                editor.putString("email", "").apply()
                editor.putBoolean("is_logged", false).apply()
            }

        }

        if (mSettings!!.getString("selectedFragment", "").toString().equals("profile")){
            mSettings.edit().putString("selectedFragment", "").apply()
            replaceFragment(profileFragment)
        }
        else {
            mSettings.edit().putString("selectedFragment", "").apply()
            replaceFragment(catalogFragment)
        }

        val bn_menu = findViewById<BottomNavigationView>(R.id.bn_menu)
        bn_menu.setOnNavigationItemSelectedListener {
            when(it.itemId){
                R.id.ic_catalog -> replaceFragment(catalogFragment)
                R.id.ic_basket -> replaceFragment(basketFragment)
                R.id.ic_profile -> replaceFragment(profileFragment)
            }
            true
        }
    }
    private fun setNotifications() {
        var i = 1
        if (user != null){
            var date = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))
            } else {TODO("VERSION.SDK_INT < O")}

            var listIssueHR = mDBHelper.listHR(user, " hrRelevance = 1 and hrDateReturn <= '$date'")
            if (listIssueHR.size > 0){
                var text:StringBuilder = java.lang.StringBuilder()
                text.append("\n")
                text.append(getString(R.string.notif_issueList_text))
                for (hr in listIssueHR){
                    text.append(hr.edition.nameBook + " : " + hr.edition.getAuthorStr() + "\t (" + hr.dateReturn + ")\n")
                }

                createNotification(getString(R.string.issueListFull), text.toString(), i++)
            }

            date = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                (LocalDateTime.now().plusDays(3)).format(DateTimeFormatter.ofPattern("yyyy-MM-dd"))
            } else {TODO("VERSION.SDK_INT < O")}

            var listNeedReturn = mDBHelper.listHR(user, " hrRelevance = 1 and hrDateReturn = '$date'")
            if (listNeedReturn.size > 0){
                var text:StringBuilder = java.lang.StringBuilder()
                text.append(getString(R.string.notif_listNeedReturn_text))
                text.append("\n")
                for (hr in listNeedReturn){
                    text.append("\t" + hr.edition.nameBook + " : " + hr.edition.getAuthorStr() + "\t (" +
                            hr.dateReturn + ")\n")
                }

                createNotification(getString(R.string.listNeedReturnFull), text.toString(), i++)
            }
        }

    }

    private fun createNotification(title: String, content: String, i: Int) {

        var resultIntent = Intent(this, HistoryReaderListActivity::class.java)
        resultIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK or Intent.FLAG_ACTIVITY_NEW_TASK )
        var resultPendingIntent = PendingIntent.getActivity(
            this, 0, resultIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val builder = NotificationCompat.Builder(this, "CHANNEL_ID")
            .setSmallIcon(R.drawable.ic_notification_important)
            .setContentTitle(title)
            .setContentText(content)
            .setContentIntent(resultPendingIntent)
            .setAutoCancel(true)
            //.setDefaults(Notification.DEFAULT_SOUND and Notification.DEFAULT_VIBRATE)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)

        val notificationManager = applicationContext.getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationChannel =
                NotificationChannel("CHANNEL_ID", "CHANNEL_ID", NotificationManager.IMPORTANCE_DEFAULT)
            notificationManager.createNotificationChannel(notificationChannel)
        }
        notificationManager.notify(i, builder.build())
    }

    fun replaceFragment(fragment: Fragment){
        if (fragment != null){
            val transaction = supportFragmentManager.beginTransaction()
            transaction.replace(R.id.fl_catalog, fragment)
            transaction.commit()
        }
    }
    }